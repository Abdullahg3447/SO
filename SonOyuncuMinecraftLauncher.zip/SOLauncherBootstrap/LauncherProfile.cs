﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.LauncherProfile
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Text;

namespace SOLauncherBootstrap
{
  internal class LauncherProfile
  {
    private long maximumRAM;

    public LauncherProfile(long maximumRAM)
    {
      this.maximumRAM = maximumRAM;
    }

    public long GetMaximumRAM()
    {
      return this.maximumRAM;
    }

    public static LauncherProfile Load(string filePath)
    {
      try
      {
        JObject jobject = JsonConvert.DeserializeObject<JObject>(File.ReadAllText(filePath, Encoding.UTF8));
        if (jobject == null)
          return (LauncherProfile) null;
        JToken jtoken = jobject.GetValue("maxram");
        return jtoken == null ? (LauncherProfile) null : new LauncherProfile(Convert.ToInt64(jtoken.ToString()));
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
      return (LauncherProfile) null;
    }
  }
}
