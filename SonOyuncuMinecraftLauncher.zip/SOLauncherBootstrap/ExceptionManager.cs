﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.ExceptionManager
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json;
using System;
using System.Windows.Forms;

namespace SOLauncherBootstrap
{
  public class ExceptionManager
  {
    private Bootstrap bootstrap;

    public ExceptionManager(Bootstrap bootstrap)
    {
      this.bootstrap = bootstrap;
    }

    public void Handle(object source, int code, Exception exception)
    {
      switch (source)
      {
        case Configuration _:
          if (code != 15)
            break;
          if (exception is JsonReaderException)
          {
            int num1 = (int) MessageBox.Show("Sunucudan gelen ayarlar geçerli değil! \n\n" + this.SimpleException(exception), "SonOyuncu Minecraft Launcher - Güncelleyici", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          }
          else
          {
            int num2 = (int) MessageBox.Show("Ayarlar yüklenirken bir hata oluştu! \n\n" + this.SimpleException(exception), "SonOyuncu Minecraft Launcher - Güncelleyici", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          }
          Environment.Exit(0);
          break;
        case Bootstrap _:
          switch (code)
          {
            case 1:
              int num3 = (int) MessageBox.Show("Java hazırlanırken bir hata oluştu! \n\n" + this.SimpleException(exception), "SonOyuncu Minecraft Launcher - Güncelleyici", MessageBoxButtons.OK, MessageBoxIcon.Hand);
              break;
            case 2:
              int num4 = (int) MessageBox.Show("Java dosyaları hazırlanırken bir hata oluştu! \n\n" + this.SimpleException(exception), "SonOyuncu Minecraft Launcher - Güncelleyici", MessageBoxButtons.OK, MessageBoxIcon.Hand);
              break;
            case 3:
              int num5 = (int) MessageBox.Show("Java'nın çalışabilirliği test edilirken bir hata oluştu! \n\n" + this.SimpleException(exception), "SonOyuncu Minecraft Launcher - Güncelleyici", MessageBoxButtons.OK, MessageBoxIcon.Hand);
              break;
            case 4:
              int num6 = (int) MessageBox.Show("Launcher hazırlanırken bir hata oluştu! \n\n" + this.SimpleException(exception), "SonOyuncu Minecraft Launcher - Güncelleyici", MessageBoxButtons.OK, MessageBoxIcon.Hand);
              Console.WriteLine("stack trace => " + exception.StackTrace);
              break;
          }
          Environment.Exit(0);
          break;
      }
    }

    private string SimpleException(Exception ex)
    {
      string str1 = ex.ToString();
      string str2 = ex.Message + ":\n";
      char[] charArray = "\n".ToCharArray();
      foreach (string str3 in str1.Split(charArray))
        str2 = !str3.Contains("\\") ? str2 + "    " + str3 + "\n" : str2 + "    " + str3.Substring(str3.LastIndexOf("\\") + 1) + "\n";
      return str2;
    }
  }
}
