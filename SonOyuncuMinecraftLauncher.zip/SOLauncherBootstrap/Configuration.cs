﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.Configuration
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net;

namespace SOLauncherBootstrap
{
  internal class Configuration
  {
    private string url_mojangConfiguration;
    private string url_launcherJAR;
    private string checksum_launcherJAR;
    private string java_preferredType;
    private string path_launcherDownload;
    private string args_launcher;

    public Configuration(Bootstrap bootstrap)
    {
      try
      {
        this.Load("https://launcher.sonoyuncu.network/bootstrap.json");
      }
      catch (Exception ex)
      {
        bootstrap.exceptionManager.Handle((object) this, 15, ex);
      }
    }

    private void Load(string url)
    {
      JObject jobject = (JObject) null;
      using (WebClient webClient = new WebClient())
      {
        string str = webClient.DownloadString(url);
        if (str == null || str.Length == 0)
          throw new Exception("SonOyuncu sunucularıyla bağlantı sağlanamadı! [" + (str == null ? "0x0F0000" : "0x0F0001") + "]");
        jobject = JsonConvert.DeserializeObject<JObject>(str);
        webClient.Dispose();
      }
      this.url_mojangConfiguration = jobject.GetValue("mojang_configuration").ToString();
      this.java_preferredType = jobject.GetValue("java_preferred_type").ToString();
      this.url_launcherJAR = jobject.GetValue("launcher_jar_url").ToString();
      this.checksum_launcherJAR = jobject.GetValue("launcher_jar_checksum").ToString();
      this.path_launcherDownload = jobject.GetValue("launcher_path").ToString();
      this.args_launcher = jobject.GetValue("launcher_args").ToString();
    }

    public string GetMojangConfigurationURL()
    {
      return this.url_mojangConfiguration;
    }

    public string GetPreferredJavaType()
    {
      return this.java_preferredType;
    }

    public string GetLauncherJARUrl()
    {
      return this.url_launcherJAR;
    }

    public string GetLauncherJARChecksum()
    {
      return this.checksum_launcherJAR;
    }

    public string GetLauncherDownloadPath()
    {
      return this.path_launcherDownload;
    }

    public string GetLauncherArguments()
    {
      return this.args_launcher;
    }
  }
}
