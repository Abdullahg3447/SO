﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.FileUtils
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using SevenZip;
using SevenZip.Compression.LZMA;
using System;
using System.IO;
using System.Security.Cryptography;

namespace SOLauncherBootstrap
{
  internal class FileUtils
  {
    public static class Cryptography
    {
      public static string GetSHA1(string filePath)
      {
        using (FileStream fileStream = File.OpenRead(filePath))
        {
          using (SHA1Managed shA1Managed = new SHA1Managed())
            return BitConverter.ToString(shA1Managed.ComputeHash((Stream) fileStream)).Replace("-", string.Empty);
        }
      }
    }

    public static class Compression
    {
      public static void DecompressLZMA(string inPath, string outPath)
      {
        Decoder decoder = new Decoder();
        FileStream fileStream1 = new FileStream(inPath, FileMode.Open);
        FileStream fileStream2 = new FileStream(outPath, FileMode.Create);
        byte[] numArray = new byte[5];
        fileStream1.Read(numArray, 0, 5);
        byte[] buffer = new byte[8];
        fileStream1.Read(buffer, 0, 8);
        long int64 = BitConverter.ToInt64(buffer, 0);
        decoder.SetDecoderProperties(numArray);
        decoder.Code((Stream) fileStream1, (Stream) fileStream2, fileStream1.Length, int64, (ICodeProgress) null);
        fileStream2.Flush();
        fileStream2.Close();
      }
    }
  }
}
