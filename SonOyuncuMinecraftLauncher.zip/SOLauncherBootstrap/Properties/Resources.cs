﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.Properties.Resources
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace SOLauncherBootstrap.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (SOLauncherBootstrap.Properties.Resources.resourceMan == null)
          SOLauncherBootstrap.Properties.Resources.resourceMan = new ResourceManager("SOLauncherBootstrap.Properties.Resources", typeof (SOLauncherBootstrap.Properties.Resources).Assembly);
        return SOLauncherBootstrap.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return SOLauncherBootstrap.Properties.Resources.resourceCulture;
      }
      set
      {
        SOLauncherBootstrap.Properties.Resources.resourceCulture = value;
      }
    }

    internal static Bitmap frame_icon
    {
      get
      {
        return (Bitmap) SOLauncherBootstrap.Properties.Resources.ResourceManager.GetObject(nameof (frame_icon), SOLauncherBootstrap.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap so_logo
    {
      get
      {
        return (Bitmap) SOLauncherBootstrap.Properties.Resources.ResourceManager.GetObject(nameof (so_logo), SOLauncherBootstrap.Properties.Resources.resourceCulture);
      }
    }
  }
}
