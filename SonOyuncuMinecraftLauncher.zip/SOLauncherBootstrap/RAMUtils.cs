﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.RAMUtils
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Microsoft.VisualBasic.Devices;

namespace SOLauncherBootstrap
{
  internal class RAMUtils
  {
    public static long GetAverageRAMForMinecraft()
    {
      long maximumRam = (long) RAMUtils.getMaximumRam();
      long num1;
      if (LauncherBootstrap.OS_IS64)
      {
        long num2 = maximumRam / 1000L * 512L;
        num1 = num2 >= 4096L ? 4096L : num2;
      }
      else
      {
        long num2 = maximumRam / 1000L * 512L;
        num1 = num2 >= 1536L ? 1536L : num2;
      }
      return num1;
    }

    public static long GetAverageInitialRAMForMinecraft()
    {
      long averageRamForMinecraft = RAMUtils.GetAverageRAMForMinecraft();
      long num = 256;
      if (num > (long) RAMUtils.getMaximumRam())
        num = 256L;
      else if (num > averageRamForMinecraft)
        num = 256L;
      return num;
    }

    public static long GetSafeRAMForMinecraft(long maximumRamL)
    {
      long num1 = maximumRamL;
      long maximumRam = (long) RAMUtils.getMaximumRam();
      long num2;
      if (LauncherBootstrap.OS_IS64)
      {
        long num3 = maximumRam / 1000L * 512L;
        long num4 = num3 >= 4096L ? 4096L : num3;
        num2 = num1;
        if (num2 > maximumRam)
          num2 = num4;
        if (num2 < 256L || num2 > (long) short.MaxValue)
          num2 = num4;
      }
      else
      {
        num2 = num1;
        if (num2 > maximumRam)
          num2 = 512L;
        if (num2 < 256L || num2 > (long) short.MaxValue)
          num2 = 512L;
      }
      return num2;
    }

    public static ulong getMaximumRam()
    {
      ulong systemRam = RAMUtils.getSystemRam();
      return !LauncherBootstrap.OS_IS64 && systemRam >= 1024UL ? 1024UL : systemRam;
    }

    public static ulong getSystemRam()
    {
      return new ComputerInfo().TotalPhysicalMemory;
    }
  }
}
