﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.Bootstrap
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Ionic.Zip;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

namespace SOLauncherBootstrap
{
  public class Bootstrap
  {
    private Configuration configuration;
    private MojangLauncherJson mojangLauncherJson;
    private int currentProgressValueOffset;

    public ExceptionManager exceptionManager { get; }

    public Bootstrap()
    {
      this.exceptionManager = new ExceptionManager(this);
    }

    public void Launch()
    {
      this.configuration = new Configuration(this);
      this.mojangLauncherJson = new MojangLauncherJson().Load(this.configuration.GetMojangConfigurationURL());
      LauncherBootstrap.userInterface.SetProgressBarMaximum(250);
      this.PrepareJava();
    }

    private void PrepareJava()
    {
      try
      {
        string downloadTempPath = PathManager.GetDownloadTempPath();
        string str = LauncherBootstrap.OS_IS64 ? "64" : "32";
        string preferredJavaType = this.configuration.GetPreferredJavaType();
        MojangLauncherJson.JavaInfo javaInfo = this.mojangLauncherJson.GetJava(preferredJavaType);
        string jdkLZMAPath = downloadTempPath + "\\" + preferredJavaType + "-windows-x" + str + "-" + javaInfo.Version() + ".lzma";
        string jdkZIPPath = downloadTempPath + "\\" + preferredJavaType + "-windows-x" + str + "-" + javaInfo.Version() + ".zip";
        string jdkExtractPath = PathManager.GetUserDirectoryPath() + "\\runtime\\" + preferredJavaType + "-x" + str + "\\" + javaInfo.Version() + "\\";
        bool flag1 = false;
        if (Directory.Exists(jdkExtractPath))
        {
          Console.WriteLine("İndirilmiş bir Java bulundu, test ediliyor...");
          flag1 = this.TestJava(jdkExtractPath, javaInfo.Version());
          Console.WriteLine(flag1 ? "Java çalışır halde, pas geçiliyor..." : "Java'nın tekrar indirilmesi gerekiyor!");
        }
        if (flag1)
        {
          this.currentProgressValueOffset += 130;
          this.PrepareLauncher(jdkExtractPath);
        }
        else
        {
          Console.Out.WriteLine("Java indiriliyor...");
          bool flag2 = true;
          if (System.IO.File.Exists(jdkLZMAPath))
          {
            Console.Out.WriteLine("Java LZMA dosyası bulundu, kontrol ediliyor...");
            string shA1 = FileUtils.Cryptography.GetSHA1(jdkLZMAPath);
            flag2 = !this.IsSHA1Equals(javaInfo.SHA1(), shA1);
            Console.Out.WriteLine("Java " + (flag2 ? "tekrar indirilecek." : "zaten indirilmiş, indirme işlemi pas geçiliyor..."));
          }
          if (flag2)
          {
            using (WebClient webcli = new WebClient())
            {
              webcli.DownloadFileAsync(new Uri(javaInfo.URL()), jdkLZMAPath);
              webcli.DownloadProgressChanged += (DownloadProgressChangedEventHandler) ((sender, args) => LauncherBootstrap.userInterface.SetProgressBar(UI.LaunchProgress.DOWNLOADING_JAVA, this.currentProgressValueOffset + args.ProgressPercentage, args.ProgressPercentage));
              webcli.DownloadFileCompleted += (AsyncCompletedEventHandler) ((sender, args) =>
              {
                webcli.Dispose();
                this.currentProgressValueOffset += 100;
                Console.Out.WriteLine("Java indirildi.");
                this.ExtractJava(jdkLZMAPath, jdkZIPPath, jdkExtractPath);
                int num = this.TestJava(jdkExtractPath, javaInfo.Version()) ? 1 : 0;
                this.currentProgressValueOffset += 10;
                LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
                if (num != 0)
                  this.PrepareLauncher(jdkExtractPath);
                else
                  this.exceptionManager.Handle((object) this, 3, new Exception("Java test edilirken bir problem oluştu, programı tekrardan başlatmayı deneyebilirsin."));
              });
            }
          }
          else
          {
            this.currentProgressValueOffset += 100;
            LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
            this.ExtractJava(jdkLZMAPath, jdkZIPPath, jdkExtractPath);
            if (this.TestJava(jdkExtractPath, javaInfo.Version()))
              this.PrepareLauncher(jdkExtractPath);
            else
              this.exceptionManager.Handle((object) this, 3, new Exception("Java test edilirken bir problem oluştu, programı tekrardan başlatmayı deneyebilirsin."));
          }
        }
      }
      catch (Exception ex)
      {
        this.exceptionManager.Handle((object) this, 1, ex);
      }
    }

    private bool ExtractJava(string jdkLZMAPath, string jdkZIPPath, string jdkExtractPath)
    {
      try
      {
        Console.Out.WriteLine("Java dosyası açılıyor...");
        LauncherBootstrap.userInterface.SetProgressBar(UI.LaunchProgress.EXTRACTING_JAVA, -1, -1);
        FileUtils.Compression.DecompressLZMA(jdkLZMAPath, jdkZIPPath);
        this.currentProgressValueOffset += 10;
        LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
        Console.Out.WriteLine("Java dosyası açıldı.");
        Console.Out.WriteLine("Java çıkartılıyor...");
        ZipFile zipFile = new ZipFile(jdkZIPPath);
        zipFile.ExtractAll(jdkExtractPath, ExtractExistingFileAction.OverwriteSilently);
        zipFile.Dispose();
        this.currentProgressValueOffset += 10;
        LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
        System.IO.File.Delete(jdkZIPPath);
        Console.Out.WriteLine("Java çıkartıldı.");
        return true;
      }
      catch (Exception ex)
      {
        this.exceptionManager.Handle((object) this, 2, ex);
        return false;
      }
    }

    private bool TestJava(string runtimePath, string expectedJavaVersion)
    {
      try
      {
        bool flag = false;
        if (!System.IO.File.Exists(runtimePath + "bin\\java.exe"))
          return false;
        Process process = Process.Start(new ProcessStartInfo()
        {
          FileName = runtimePath + "bin\\java.exe",
          Arguments = "-version",
          UseShellExecute = false,
          RedirectStandardError = true,
          CreateNoWindow = true
        });
        while (!process.StandardError.EndOfStream)
        {
          if (process.StandardError.ReadLine().ToLower().Equals("java version \"" + expectedJavaVersion + "\""))
          {
            flag = true;
            break;
          }
        }
        process.WaitForExit();
        return flag;
      }
      catch (Exception ex)
      {
        this.exceptionManager.Handle((object) this, 3, ex);
        return false;
      }
    }

    private void PrepareLauncher(string javaRuntimePath)
    {
      try
      {
        string jarDownloadPath = PathManager.GetAppPath() + this.configuration.GetLauncherDownloadPath();
        bool flag = false;
        if (System.IO.File.Exists(jarDownloadPath))
          flag = this.IsSHA1Equals(this.configuration.GetLauncherJARChecksum(), FileUtils.Cryptography.GetSHA1(jarDownloadPath));
        if (flag)
        {
          this.currentProgressValueOffset += 110;
          LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
          this.StartLauncher(javaRuntimePath);
        }
        else
        {
          using (WebClient webcli = new WebClient())
          {
            webcli.DownloadFileAsync(new Uri(this.configuration.GetLauncherJARUrl()), jarDownloadPath);
            webcli.DownloadProgressChanged += (DownloadProgressChangedEventHandler) ((sender, args) => LauncherBootstrap.userInterface.SetProgressBar(UI.LaunchProgress.DOWNLOADING_LAUNCHER, this.currentProgressValueOffset + args.ProgressPercentage, args.ProgressPercentage));
            webcli.DownloadFileCompleted += (AsyncCompletedEventHandler) ((sender, args) =>
            {
              webcli.Dispose();
              if (this.IsSHA1Equals(this.configuration.GetLauncherJARChecksum(), FileUtils.Cryptography.GetSHA1(jarDownloadPath)))
              {
                this.currentProgressValueOffset += 110;
                LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
                this.StartLauncher(javaRuntimePath);
              }
              else
                this.exceptionManager.Handle((object) this, 3, new Exception("SonOyuncu Minecraft Launcher indirilirken dosya bütünlüğü sağlanamadı."));
            });
          }
        }
      }
      catch (Exception ex)
      {
        this.exceptionManager.Handle((object) this, 4, ex);
      }
    }

    private void StartLauncher(string javaRuntimePath)
    {
      this.currentProgressValueOffset += 10;
      LauncherBootstrap.userInterface.SetProgressBarValue(this.currentProgressValueOffset);
      LauncherBootstrap.userInterface.SetProgressBar(UI.LaunchProgress.STARTING_LAUNCHER, -1, -1);
      string appPath = PathManager.GetAppPath();
      LauncherProfile launcherProfile = LauncherProfile.Load(appPath + "profile.json");
      string str1 = javaRuntimePath + "bin\\javaw.exe";
      string str2 = appPath + this.configuration.GetLauncherDownloadPath();
      string str3 = this.configuration.GetLauncherArguments().Replace("%initRAM%", string.Concat((object) RAMUtils.GetAverageInitialRAMForMinecraft())).Replace("%maxRAM%", string.Concat((object) (launcherProfile != null ? RAMUtils.GetSafeRAMForMinecraft(launcherProfile.GetMaximumRAM()) : RAMUtils.GetAverageRAMForMinecraft()))).Replace("%runArgs%", "-Djava.library.path=\"" + PathManager.GetExtractPath() + "\" -jar \"" + str2 + "\" " + this.Decrypt("7C?>?<>A>:>:"));
      Console.WriteLine(str3);
      Process.Start(new ProcessStartInfo()
      {
        WorkingDirectory = appPath,
        FileName = str1,
        Arguments = str3,
        UseShellExecute = false
      });
      Thread.Sleep(1000);
      Environment.Exit(0);
    }

    private bool IsSHA1Equals(string expected, string file)
    {
      return expected.ToLower().Equals(file.ToLower());
    }

    private string Decrypt(string key)
    {
      string s = "";
      foreach (char ch in key.ToCharArray())
      {
        int num = (int) Convert.ToInt16(ch) - 10;
        s += Convert.ToChar(num).ToString();
      }
      return Encoding.UTF8.GetString(Encoding.UTF8.GetBytes(s));
    }
  }
}
