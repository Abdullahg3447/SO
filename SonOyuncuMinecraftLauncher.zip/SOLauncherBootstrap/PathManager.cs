﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.PathManager
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.IO;

namespace SOLauncherBootstrap
{
  internal class PathManager
  {
    public static string GetUserDirectoryPath()
    {
      string fullName = Directory.GetParent(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)).FullName;
      if (Environment.OSVersion.Version.Major >= 6)
        fullName = Directory.GetParent(fullName).ToString();
      return fullName;
    }

    public static string GetDownloadTempPath()
    {
      string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.sonoyuncu\\bootstrap\\temp\\";
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      return path;
    }

    public static string GetAppPath()
    {
      string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.sonoyuncu\\";
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      return path;
    }

    public static string GetExtractPath()
    {
      string path = PathManager.GetAppPath() + "libraries\\extract";
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      return path;
    }
  }
}
