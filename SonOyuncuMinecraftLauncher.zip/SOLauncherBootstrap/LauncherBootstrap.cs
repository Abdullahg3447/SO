﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.LauncherBootstrap
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace SOLauncherBootstrap
{
  internal static class LauncherBootstrap
  {
    public static bool OS_IS64;
    public static UI userInterface;

    [STAThread]
    private static void Main()
    {
      ServicePointManager.SecurityProtocol = (SecurityProtocolType) 4032;
      LauncherBootstrap.start();
    }

    private static void start()
    {
      LauncherBootstrap.OS_IS64 = OSArchitecture.Is64BitOperatingSystem();
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      LauncherBootstrap.userInterface = new UI();
      LauncherBootstrap.userInterface.Shown += (EventHandler) ((source, args) => new Thread((ThreadStart) (() => new Bootstrap().Launch()))
      {
        IsBackground = false
      }.Start());
      Application.Run((Form) LauncherBootstrap.userInterface);
    }
  }
}
