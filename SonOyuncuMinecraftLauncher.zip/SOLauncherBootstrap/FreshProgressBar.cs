﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.FreshProgressBar
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace SOLauncherBootstrap
{
  public class FreshProgressBar : ProgressBar
  {
    private Color color;
    private IContainer components;

    public FreshProgressBar(Color color)
    {
      this.color = color;
      Control.CheckForIllegalCrossThreadCalls = false;
      this.InitializeComponent();
      this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
    }

    protected override void OnPaint(PaintEventArgs pe)
    {
      Rectangle clientRectangle = this.ClientRectangle;
      Graphics graphics = pe.Graphics;
      Brush brush = (Brush) new SolidBrush(this.color);
      int width = (int) Math.Round((double) this.Value / (double) this.Maximum * (double) clientRectangle.Width);
      graphics.FillRectangle(brush, 0, 0, width, clientRectangle.Height);
      brush.Dispose();
      graphics.Dispose();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
    }
  }
}
