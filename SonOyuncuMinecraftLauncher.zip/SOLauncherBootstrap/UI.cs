﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.UI
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using SOLauncherBootstrap.Properties;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace SOLauncherBootstrap
{
  public class UI : Form
  {
    private IContainer components;
    private UI.LaunchProgress progress_lastType;
    private PictureBox logo;
    private FreshProgressBar progressBar;
    private Label progressText;

    public UI()
    {
      this.InitializeComponent();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (UI));
      this.progressText = new Label();
      this.progressBar = new FreshProgressBar(Color.FromArgb(41, 186, 234));
      this.logo = new PictureBox();
      ((ISupportInitialize) this.logo).BeginInit();
      this.SuspendLayout();
      this.progressText.Font = new Font("Calibri", 10f, FontStyle.Bold, GraphicsUnit.Point, (byte) 162);
      this.progressText.ForeColor = Color.FromArgb(41, 186, 234);
      this.progressText.Location = new Point(0, 282);
      this.progressText.Name = "progressText";
      this.progressText.Size = new Size(630, 15);
      this.progressText.TabIndex = 2;
      this.progressText.Text = "sunucuya bağlanılıyor | 0%";
      this.progressText.TextAlign = ContentAlignment.MiddleCenter;
      this.progressBar.Location = new Point(0, 302);
      this.progressBar.Name = "progressBarBox";
      this.progressBar.Size = new Size(630, 13);
      this.progressBar.TabIndex = 1;
      this.progressBar.TabStop = false;
      this.logo.Image = (Image) Resources.so_logo;
      this.logo.Location = new Point(276, 37);
      this.logo.Name = "logo";
      this.logo.Size = new Size(78, 89);
      this.logo.TabIndex = 0;
      this.logo.TabStop = false;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.FromArgb(20, 20, 20);
      this.ClientSize = new Size(630, 315);
      this.ControlBox = false;
      this.Controls.Add((Control) this.progressText);
      this.Controls.Add((Control) this.progressBar);
      this.Controls.Add((Control) this.logo);
      this.FormBorderStyle = FormBorderStyle.None;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (UI);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "SonOyuncu Minecraft Launcher";
      this.Icon = this.GetFormIcon();
      ((ISupportInitialize) this.logo).EndInit();
      this.ResumeLayout(false);
    }

    public void SetProgressBarValue(int value)
    {
      if (this.progressBar.Value == value)
        return;
      this.progressBar.Value = value;
    }

    public void SetProgressBarMaximum(int value)
    {
      this.progressBar.Maximum = value;
    }

    public void SetProgressBar(UI.LaunchProgress type, int value, int originalValue)
    {
      if (this.progressBar.Value == value && this.progress_lastType == type)
        return;
      if (value != -1)
        this.progressBar.Value = value;
      this.progress_lastType = type;
      string str1 = "hazırlanıyor";
      if (type == UI.LaunchProgress.DOWNLOADING_JAVA)
        str1 = "Java indiriliyor";
      if (type == UI.LaunchProgress.EXTRACTING_JAVA)
        str1 = "Java çıkartılıyor";
      if (type == UI.LaunchProgress.TESTING_JAVA)
        str1 = "Java test ediliyor";
      if (type == UI.LaunchProgress.DOWNLOADING_LAUNCHER)
        str1 = "SonOyuncu Minecraft Launcher indiriliyor";
      if (type == UI.LaunchProgress.STARTING_LAUNCHER)
        str1 = "SonOyuncu Minecraft Launcher başlatılıyor";
      string str2 = str1;
      if (originalValue != -1)
        str2 = str2 + " | " + (object) originalValue + "%";
      this.progressText.Text = str2;
    }

    public Icon GetFormIcon()
    {
      using (Bitmap frameIcon = Resources.frame_icon)
        return Icon.FromHandle(frameIcon.GetHicon());
    }

    public enum LaunchProgress
    {
      DOWNLOADING_JAVA,
      EXTRACTING_JAVA,
      TESTING_JAVA,
      DOWNLOADING_LAUNCHER,
      STARTING_LAUNCHER,
    }
  }
}
