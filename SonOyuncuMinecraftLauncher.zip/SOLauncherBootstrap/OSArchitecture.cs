﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.OSArchitecture
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Runtime.InteropServices;

namespace SOLauncherBootstrap
{
  internal class OSArchitecture
  {
    public static bool Is64BitOperatingSystem()
    {
      bool wow64Process;
      return IntPtr.Size == 8 || ((!OSArchitecture.DoesWin32MethodExist("kernel32.dll", "IsWow64Process") ? 0 : (OSArchitecture.IsWow64Process(OSArchitecture.GetCurrentProcess(), out wow64Process) ? 1 : 0)) & (wow64Process ? 1 : 0)) != 0;
    }

    private static bool DoesWin32MethodExist(string moduleName, string methodName)
    {
      IntPtr moduleHandle = OSArchitecture.GetModuleHandle(moduleName);
      return !(moduleHandle == IntPtr.Zero) && OSArchitecture.GetProcAddress(moduleHandle, methodName) != IntPtr.Zero;
    }

    [DllImport("kernel32.dll")]
    private static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    private static extern IntPtr GetModuleHandle(string moduleName);

    [DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetProcAddress(IntPtr hModule, [MarshalAs(UnmanagedType.LPStr)] string procName);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsWow64Process(IntPtr hProcess, out bool wow64Process);
  }
}
