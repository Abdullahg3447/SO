﻿// Decompiled with JetBrains decompiler
// Type: SOLauncherBootstrap.MojangLauncherJson
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;

namespace SOLauncherBootstrap
{
  internal class MojangLauncherJson
  {
    private Dictionary<string, MojangLauncherJson.JavaInfo> javaInfoMap;

    public MojangLauncherJson Load(string url)
    {
      JObject jobject = (JObject) null;
      using (WebClient webClient = new WebClient())
      {
        jobject = JsonConvert.DeserializeObject<JObject>(webClient.DownloadString(url));
        webClient.Dispose();
      }
      string propertyName = LauncherBootstrap.OS_IS64 ? "64" : "32";
      this.javaInfoMap = jobject.GetValue("windows").ToObject<JObject>().GetValue(propertyName).ToObject<JObject>().ToObject<Dictionary<string, MojangLauncherJson.JavaInfo>>();
      return this;
    }

    public MojangLauncherJson.JavaInfo GetJava(string name)
    {
      return this.javaInfoMap[name];
    }

    public class JavaInfo
    {
      private string sha1;
      private string url;
      private string version;

      public JavaInfo(string sha1, string url, string version)
      {
        this.sha1 = sha1;
        this.url = url;
        this.version = version;
      }

      public string SHA1()
      {
        return this.sha1;
      }

      public string URL()
      {
        return this.url;
      }

      public string Version()
      {
        return this.version;
      }
    }
  }
}
