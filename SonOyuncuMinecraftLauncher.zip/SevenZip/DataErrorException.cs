﻿// Decompiled with JetBrains decompiler
// Type: SevenZip.DataErrorException
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;

namespace SevenZip
{
  internal class DataErrorException : ApplicationException
  {
    public DataErrorException()
      : base("Data Error")
    {
    }
  }
}
