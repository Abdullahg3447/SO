﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Minecraft Roleplay Minecraft Launcher")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SonOyuncu")]
[assembly: AssemblyProduct("SonOyuncu Minecraft Launcher")]
[assembly: AssemblyCopyright("KaptanUcar - Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: Guid("c3643656-3dc0-4790-ae56-51b52e59553f")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: NeutralResourcesLanguage("tr")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
