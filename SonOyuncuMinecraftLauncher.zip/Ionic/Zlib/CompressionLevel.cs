﻿// Decompiled with JetBrains decompiler
// Type: Ionic.Zlib.CompressionLevel
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
  [ComVisible(true)]
  public enum CompressionLevel
  {
    Level0 = 0,
    None = 0,
    BestSpeed = 1,
    Level1 = 1,
    Level2 = 2,
    Level3 = 3,
    Level4 = 4,
    Level5 = 5,
    Default = 6,
    Level6 = 6,
    Level7 = 7,
    Level8 = 8,
    BestCompression = 9,
    Level9 = 9,
  }
}
