﻿// Decompiled with JetBrains decompiler
// Type: Ionic.Zlib.ZlibStreamFlavor
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Ionic.Zlib
{
  internal enum ZlibStreamFlavor
  {
    ZLIB = 1950, // 0x0000079E
    DEFLATE = 1951, // 0x0000079F
    GZIP = 1952, // 0x000007A0
  }
}
