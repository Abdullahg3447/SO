﻿// Decompiled with JetBrains decompiler
// Type: Ionic.Zip.ZipException
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
  [Guid("ebc25cf6-9120-4283-b972-0e5520d00006")]
  [ComVisible(true)]
  [Serializable]
  public class ZipException : Exception
  {
    public ZipException()
    {
    }

    public ZipException(string message)
      : base(message)
    {
    }

    public ZipException(string message, Exception innerException)
      : base(message, innerException)
    {
    }

    protected ZipException(SerializationInfo info, StreamingContext context)
      : base(info, context)
    {
    }
  }
}
