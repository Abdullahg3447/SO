﻿// Decompiled with JetBrains decompiler
// Type: Ionic.Zip.EncryptionAlgorithm
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Runtime.InteropServices;

namespace Ionic.Zip
{
  [ComVisible(true)]
  public enum EncryptionAlgorithm
  {
    None,
    PkzipWeak,
    WinZipAes128,
    WinZipAes256,
    Unsupported,
  }
}
