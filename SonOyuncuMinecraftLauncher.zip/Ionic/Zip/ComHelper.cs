﻿// Decompiled with JetBrains decompiler
// Type: Ionic.Zip.ComHelper
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Runtime.InteropServices;

namespace Ionic.Zip
{
  [Guid("ebc25cf6-9120-4283-b972-0e5520d0000F")]
  [ComVisible(true)]
  [ClassInterface(ClassInterfaceType.AutoDispatch)]
  public class ComHelper
  {
    public bool IsZipFile(string filename)
    {
      return ZipFile.IsZipFile(filename);
    }

    public bool IsZipFileWithExtract(string filename)
    {
      return ZipFile.IsZipFile(filename, true);
    }

    public bool CheckZip(string filename)
    {
      return ZipFile.CheckZip(filename);
    }

    public bool CheckZipPassword(string filename, string password)
    {
      return ZipFile.CheckZipPassword(filename, password);
    }

    public void FixZipDirectory(string filename)
    {
      ZipFile.FixZipDirectory(filename);
    }

    public string GetZipLibraryVersion()
    {
      return ZipFile.LibraryVersion.ToString();
    }
  }
}
