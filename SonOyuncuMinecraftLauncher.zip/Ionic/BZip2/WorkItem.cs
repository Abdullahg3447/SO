﻿// Decompiled with JetBrains decompiler
// Type: Ionic.BZip2.WorkItem
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.IO;

namespace Ionic.BZip2
{
  internal class WorkItem
  {
    public int index;
    public MemoryStream ms;
    public int ordinal;
    public BitWriter bw;

    public BZip2Compressor Compressor { get; private set; }

    public WorkItem(int ix, int blockSize)
    {
      this.ms = new MemoryStream();
      this.bw = new BitWriter((Stream) this.ms);
      this.Compressor = new BZip2Compressor(this.bw, blockSize);
      this.index = ix;
    }
  }
}
