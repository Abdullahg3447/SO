﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Schema.JsonSchemaResolver
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Collections.Generic;
using System.Linq;

namespace Newtonsoft.Json.Schema
{
  [Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
  public class JsonSchemaResolver
  {
    public IList<JsonSchema> LoadedSchemas { get; protected set; }

    public JsonSchemaResolver()
    {
      this.LoadedSchemas = (IList<JsonSchema>) new List<JsonSchema>();
    }

    public virtual JsonSchema GetSchema(string reference)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      JsonSchemaResolver.\u003C\u003Ec__DisplayClass5_0 cDisplayClass50 = new JsonSchemaResolver.\u003C\u003Ec__DisplayClass5_0();
      // ISSUE: reference to a compiler-generated field
      cDisplayClass50.reference = reference;
      // ISSUE: method pointer
      // ISSUE: method pointer
      return (JsonSchema) Enumerable.SingleOrDefault<JsonSchema>((IEnumerable<M0>) this.LoadedSchemas, (Func<M0, bool>) new Func<JsonSchema, bool>((object) cDisplayClass50, __methodptr(\u003CGetSchema\u003Eb__0))) ?? (JsonSchema) Enumerable.SingleOrDefault<JsonSchema>((IEnumerable<M0>) this.LoadedSchemas, (Func<M0, bool>) new Func<JsonSchema, bool>((object) cDisplayClass50, __methodptr(\u003CGetSchema\u003Eb__1)));
    }
  }
}
