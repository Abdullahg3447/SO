﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Schema.UndefinedSchemaIdHandling
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;

namespace Newtonsoft.Json.Schema
{
  [Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
  public enum UndefinedSchemaIdHandling
  {
    None,
    UseTypeName,
    UseAssemblyQualifiedName,
  }
}
