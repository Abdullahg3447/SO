﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Linq.JsonPath.ArrayIndexFilter
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace Newtonsoft.Json.Linq.JsonPath
{
  internal class ArrayIndexFilter : PathFilter
  {
    public int? Index { get; set; }

    public override IEnumerable<JToken> ExecuteFilter(
      JToken root,
      IEnumerable<JToken> current,
      bool errorWhenNoMatch)
    {
      foreach (JToken jtoken1 in current)
      {
        JToken t = jtoken1;
        int? index = this.Index;
        if (index.HasValue)
        {
          JToken t1 = t;
          int num = errorWhenNoMatch ? 1 : 0;
          index = this.Index;
          int valueOrDefault = index.GetValueOrDefault();
          JToken tokenIndex = PathFilter.GetTokenIndex(t1, num != 0, valueOrDefault);
          if (tokenIndex != null)
            yield return tokenIndex;
        }
        else if (t is JArray || t is JConstructor)
        {
          foreach (JToken jtoken2 in (IEnumerable<JToken>) t)
            yield return jtoken2;
        }
        else if (errorWhenNoMatch)
          throw new JsonException("Index * not valid on {0}.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) t.GetType().Name));
        t = (JToken) null;
      }
    }
  }
}
