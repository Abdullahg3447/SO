﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Linq.JsonPath.FieldMultipleFilter
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Newtonsoft.Json.Linq.JsonPath
{
  internal class FieldMultipleFilter : PathFilter
  {
    public List<string> Names { get; set; }

    public override IEnumerable<JToken> ExecuteFilter(
      JToken root,
      IEnumerable<JToken> current,
      bool errorWhenNoMatch)
    {
      foreach (JToken jtoken1 in current)
      {
        JToken t = jtoken1;
        if (t is JObject o)
        {
          foreach (string name1 in this.Names)
          {
            string name = name1;
            JToken jtoken2 = o[name];
            if (jtoken2 != null)
              yield return jtoken2;
            if (errorWhenNoMatch)
              throw new JsonException("Property '{0}' does not exist on JObject.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) name));
            name = (string) null;
          }
        }
        else if (errorWhenNoMatch)
        {
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: reference to a compiler-generated field
          // ISSUE: method pointer
          throw new JsonException("Properties {0} not valid on {1}.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) string.Join(", ", (IEnumerable<string>) Enumerable.Select<string, string>((IEnumerable<M0>) this.Names, (Func<M0, M1>) (FieldMultipleFilter.\u003C\u003Ec.\u003C\u003E9__4_0 ?? (FieldMultipleFilter.\u003C\u003Ec.\u003C\u003E9__4_0 = new Func<string, string>((object) FieldMultipleFilter.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CExecuteFilter\u003Eb__4_0)))))), (object) t.GetType().Name));
        }
        o = (JObject) null;
        t = (JToken) null;
      }
    }
  }
}
