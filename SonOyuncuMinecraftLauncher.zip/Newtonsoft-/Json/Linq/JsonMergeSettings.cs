﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Linq.JsonMergeSettings
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;

namespace Newtonsoft.Json.Linq
{
  public class JsonMergeSettings
  {
    private MergeArrayHandling _mergeArrayHandling;
    private MergeNullValueHandling _mergeNullValueHandling;

    public MergeArrayHandling MergeArrayHandling
    {
      get
      {
        return this._mergeArrayHandling;
      }
      set
      {
        if (value < MergeArrayHandling.Concat || value > MergeArrayHandling.Merge)
          throw new ArgumentOutOfRangeException(nameof (value));
        this._mergeArrayHandling = value;
      }
    }

    public MergeNullValueHandling MergeNullValueHandling
    {
      get
      {
        return this._mergeNullValueHandling;
      }
      set
      {
        if (value < MergeNullValueHandling.Ignore || value > MergeNullValueHandling.Merge)
          throw new ArgumentOutOfRangeException(nameof (value));
        this._mergeNullValueHandling = value;
      }
    }
  }
}
