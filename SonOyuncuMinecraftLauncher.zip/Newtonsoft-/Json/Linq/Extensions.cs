﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Linq.Extensions
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Newtonsoft.Json.Linq
{
  public static class Extensions
  {
    public static IJEnumerable<JToken> Ancestors<T>(this IEnumerable<T> source) where T : JToken
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return ((IEnumerable<JToken>) Enumerable.SelectMany<T, JToken>(source, (Func<M0, IEnumerable<M1>>) (Extensions.\u003C\u003Ec__0<T>.\u003C\u003E9__0_0 ?? (Extensions.\u003C\u003Ec__0<T>.\u003C\u003E9__0_0 = new Func<T, IEnumerable<JToken>>((object) Extensions.\u003C\u003Ec__0<T>.\u003C\u003E9, __methodptr(\u003CAncestors\u003Eb__0_0)))))).AsJEnumerable();
    }

    public static IJEnumerable<JToken> AncestorsAndSelf<T>(
      this IEnumerable<T> source)
      where T : JToken
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return ((IEnumerable<JToken>) Enumerable.SelectMany<T, JToken>(source, (Func<M0, IEnumerable<M1>>) (Extensions.\u003C\u003Ec__1<T>.\u003C\u003E9__1_0 ?? (Extensions.\u003C\u003Ec__1<T>.\u003C\u003E9__1_0 = new Func<T, IEnumerable<JToken>>((object) Extensions.\u003C\u003Ec__1<T>.\u003C\u003E9, __methodptr(\u003CAncestorsAndSelf\u003Eb__1_0)))))).AsJEnumerable();
    }

    public static IJEnumerable<JToken> Descendants<T>(this IEnumerable<T> source) where T : JContainer
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return ((IEnumerable<JToken>) Enumerable.SelectMany<T, JToken>(source, (Func<M0, IEnumerable<M1>>) (Extensions.\u003C\u003Ec__2<T>.\u003C\u003E9__2_0 ?? (Extensions.\u003C\u003Ec__2<T>.\u003C\u003E9__2_0 = new Func<T, IEnumerable<JToken>>((object) Extensions.\u003C\u003Ec__2<T>.\u003C\u003E9, __methodptr(\u003CDescendants\u003Eb__2_0)))))).AsJEnumerable();
    }

    public static IJEnumerable<JToken> DescendantsAndSelf<T>(
      this IEnumerable<T> source)
      where T : JContainer
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return ((IEnumerable<JToken>) Enumerable.SelectMany<T, JToken>(source, (Func<M0, IEnumerable<M1>>) (Extensions.\u003C\u003Ec__3<T>.\u003C\u003E9__3_0 ?? (Extensions.\u003C\u003Ec__3<T>.\u003C\u003E9__3_0 = new Func<T, IEnumerable<JToken>>((object) Extensions.\u003C\u003Ec__3<T>.\u003C\u003E9, __methodptr(\u003CDescendantsAndSelf\u003Eb__3_0)))))).AsJEnumerable();
    }

    public static IJEnumerable<JProperty> Properties(
      this IEnumerable<JObject> source)
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return ((IEnumerable<JProperty>) Enumerable.SelectMany<JObject, JProperty>((IEnumerable<M0>) source, (Func<M0, IEnumerable<M1>>) (Extensions.\u003C\u003Ec.\u003C\u003E9__4_0 ?? (Extensions.\u003C\u003Ec.\u003C\u003E9__4_0 = new Func<JObject, IEnumerable<JProperty>>((object) Extensions.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CProperties\u003Eb__4_0)))))).AsJEnumerable<JProperty>();
    }

    public static IJEnumerable<JToken> Values(
      this IEnumerable<JToken> source,
      object key)
    {
      return source.Values<JToken, JToken>(key).AsJEnumerable();
    }

    public static IJEnumerable<JToken> Values(this IEnumerable<JToken> source)
    {
      return source.Values((object) null);
    }

    public static IEnumerable<U> Values<U>(this IEnumerable<JToken> source, object key)
    {
      return source.Values<JToken, U>(key);
    }

    public static IEnumerable<U> Values<U>(this IEnumerable<JToken> source)
    {
      return source.Values<JToken, U>((object) null);
    }

    public static U Value<U>(this IEnumerable<JToken> value)
    {
      return value.Value<JToken, U>();
    }

    public static U Value<T, U>(this IEnumerable<T> value) where T : JToken
    {
      ValidationUtils.ArgumentNotNull((object) value, nameof (value));
      if (!(value is JToken token))
        throw new ArgumentException("Source value must be a JToken.");
      return token.Convert<JToken, U>();
    }

    internal static IEnumerable<U> Values<T, U>(this IEnumerable<T> source, object key) where T : JToken
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      if (key == null)
      {
        foreach (T obj in source)
        {
          T token = obj;
          if (token is JValue token)
          {
            yield return token.Convert<JValue, U>();
          }
          else
          {
            foreach (JToken child in token.Children())
              yield return child.Convert<JToken, U>();
          }
          token = default (T);
        }
      }
      else
      {
        foreach (T obj in source)
        {
          JToken token = ((T) obj)[key];
          if (token != null)
            yield return token.Convert<JToken, U>();
        }
      }
    }

    public static IJEnumerable<JToken> Children<T>(this IEnumerable<T> source) where T : JToken
    {
      return source.Children<T, JToken>().AsJEnumerable();
    }

    public static IEnumerable<U> Children<T, U>(this IEnumerable<T> source) where T : JToken
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return ((IEnumerable<JToken>) Enumerable.SelectMany<T, JToken>(source, (Func<M0, IEnumerable<M1>>) (Extensions.\u003C\u003Ec__13<T, U>.\u003C\u003E9__13_0 ?? (Extensions.\u003C\u003Ec__13<T, U>.\u003C\u003E9__13_0 = new Func<T, IEnumerable<JToken>>((object) Extensions.\u003C\u003Ec__13<T, U>.\u003C\u003E9, __methodptr(\u003CChildren\u003Eb__13_0)))))).Convert<JToken, U>();
    }

    internal static IEnumerable<U> Convert<T, U>(this IEnumerable<T> source) where T : JToken
    {
      ValidationUtils.ArgumentNotNull((object) source, nameof (source));
      foreach (T obj in source)
        yield return ((T) obj).Convert<JToken, U>();
    }

    internal static U Convert<T, U>(this T token) where T : JToken
    {
      if ((object) token == null)
        return default (U);
      if ((object) token is U && Type.op_Inequality(typeof (U), typeof (IComparable)) && Type.op_Inequality(typeof (U), typeof (IFormattable)))
        return (U) (object) token;
      if (!(token is JValue jvalue))
        throw new InvalidCastException("Cannot cast {0} to {1}.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) token.GetType(), (object) typeof (T)));
      if (jvalue.Value is U)
        return (U) jvalue.Value;
      Type type = typeof (U);
      if (ReflectionUtils.IsNullableType(type))
      {
        if (jvalue.Value == null)
          return default (U);
        type = Nullable.GetUnderlyingType(type);
      }
      return (U) System.Convert.ChangeType(jvalue.Value, type, (IFormatProvider) CultureInfo.InvariantCulture);
    }

    public static IJEnumerable<JToken> AsJEnumerable(
      this IEnumerable<JToken> source)
    {
      return source.AsJEnumerable<JToken>();
    }

    public static IJEnumerable<T> AsJEnumerable<T>(this IEnumerable<T> source) where T : JToken
    {
      if (source == null)
        return (IJEnumerable<T>) null;
      return source is IJEnumerable<T> ? (IJEnumerable<T>) source : (IJEnumerable<T>) new JEnumerable<T>(source);
    }
  }
}
