﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Linq.JsonLoadSettings
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;

namespace Newtonsoft.Json.Linq
{
  public class JsonLoadSettings
  {
    private CommentHandling _commentHandling;
    private LineInfoHandling _lineInfoHandling;

    public JsonLoadSettings()
    {
      this._lineInfoHandling = LineInfoHandling.Load;
      this._commentHandling = CommentHandling.Ignore;
    }

    public CommentHandling CommentHandling
    {
      get
      {
        return this._commentHandling;
      }
      set
      {
        if (value < CommentHandling.Ignore || value > CommentHandling.Load)
          throw new ArgumentOutOfRangeException(nameof (value));
        this._commentHandling = value;
      }
    }

    public LineInfoHandling LineInfoHandling
    {
      get
      {
        return this._lineInfoHandling;
      }
      set
      {
        if (value < LineInfoHandling.Ignore || value > LineInfoHandling.Load)
          throw new ArgumentOutOfRangeException(nameof (value));
        this._lineInfoHandling = value;
      }
    }
  }
}
