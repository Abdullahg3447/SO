﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Converters.XTextWrapper
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
  internal class XTextWrapper : XObjectWrapper
  {
    private XText Text
    {
      get
      {
        return (XText) this.WrappedNode;
      }
    }

    public XTextWrapper(XText text)
      : base((XObject) text)
    {
    }

    public override string Value
    {
      get
      {
        return this.Text.Value;
      }
      set
      {
        this.Text.Value = value;
      }
    }

    public override IXmlNode ParentNode
    {
      get
      {
        return this.Text.Parent == null ? (IXmlNode) null : XContainerWrapper.WrapNode((XObject) this.Text.Parent);
      }
    }
  }
}
