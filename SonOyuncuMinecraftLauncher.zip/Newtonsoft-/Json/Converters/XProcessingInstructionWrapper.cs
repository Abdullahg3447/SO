﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Converters.XProcessingInstructionWrapper
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
  internal class XProcessingInstructionWrapper : XObjectWrapper
  {
    private XProcessingInstruction ProcessingInstruction
    {
      get
      {
        return (XProcessingInstruction) this.WrappedNode;
      }
    }

    public XProcessingInstructionWrapper(XProcessingInstruction processingInstruction)
      : base((XObject) processingInstruction)
    {
    }

    public override string LocalName
    {
      get
      {
        return this.ProcessingInstruction.Target;
      }
    }

    public override string Value
    {
      get
      {
        return this.ProcessingInstruction.Data;
      }
      set
      {
        this.ProcessingInstruction.Data = value;
      }
    }
  }
}
