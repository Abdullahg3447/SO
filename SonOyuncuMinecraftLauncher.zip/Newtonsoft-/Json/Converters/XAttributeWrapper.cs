﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Converters.XAttributeWrapper
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
  internal class XAttributeWrapper : XObjectWrapper
  {
    private XAttribute Attribute
    {
      get
      {
        return (XAttribute) this.WrappedNode;
      }
    }

    public XAttributeWrapper(XAttribute attribute)
      : base((XObject) attribute)
    {
    }

    public override string Value
    {
      get
      {
        return this.Attribute.Value;
      }
      set
      {
        this.Attribute.Value = value;
      }
    }

    public override string LocalName
    {
      get
      {
        return this.Attribute.Name.LocalName;
      }
    }

    public override string NamespaceUri
    {
      get
      {
        return this.Attribute.Name.NamespaceName;
      }
    }

    public override IXmlNode ParentNode
    {
      get
      {
        return this.Attribute.Parent == null ? (IXmlNode) null : XContainerWrapper.WrapNode((XObject) this.Attribute.Parent);
      }
    }
  }
}
