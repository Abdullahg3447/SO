﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Converters.XObjectWrapper
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
  internal class XObjectWrapper : IXmlNode
  {
    private readonly XObject _xmlObject;

    public XObjectWrapper(XObject xmlObject)
    {
      this._xmlObject = xmlObject;
    }

    public object WrappedNode
    {
      get
      {
        return (object) this._xmlObject;
      }
    }

    public virtual XmlNodeType NodeType
    {
      get
      {
        return this._xmlObject.NodeType;
      }
    }

    public virtual string LocalName
    {
      get
      {
        return (string) null;
      }
    }

    public virtual List<IXmlNode> ChildNodes
    {
      get
      {
        return XmlNodeConverter.EmptyChildNodes;
      }
    }

    public virtual List<IXmlNode> Attributes
    {
      get
      {
        return XmlNodeConverter.EmptyChildNodes;
      }
    }

    public virtual IXmlNode ParentNode
    {
      get
      {
        return (IXmlNode) null;
      }
    }

    public virtual string Value
    {
      get
      {
        return (string) null;
      }
      set
      {
        throw new InvalidOperationException();
      }
    }

    public virtual IXmlNode AppendChild(IXmlNode newChild)
    {
      throw new InvalidOperationException();
    }

    public virtual string NamespaceUri
    {
      get
      {
        return (string) null;
      }
    }
  }
}
