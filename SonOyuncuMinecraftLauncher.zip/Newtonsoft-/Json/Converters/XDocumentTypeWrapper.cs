﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Converters.XDocumentTypeWrapper
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
  internal class XDocumentTypeWrapper : XObjectWrapper, IXmlDocumentType, IXmlNode
  {
    private readonly XDocumentType _documentType;

    public XDocumentTypeWrapper(XDocumentType documentType)
      : base((XObject) documentType)
    {
      this._documentType = documentType;
    }

    public string Name
    {
      get
      {
        return this._documentType.Name;
      }
    }

    public string System
    {
      get
      {
        return this._documentType.SystemId;
      }
    }

    public string Public
    {
      get
      {
        return this._documentType.PublicId;
      }
    }

    public string InternalSubset
    {
      get
      {
        return this._documentType.InternalSubset;
      }
    }

    public override string LocalName
    {
      get
      {
        return "DOCTYPE";
      }
    }
  }
}
