﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Bson.BsonString
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json.Bson
{
  internal class BsonString : BsonValue
  {
    public int ByteCount { get; set; }

    public bool IncludeLength { get; }

    public BsonString(object value, bool includeLength)
      : base(value, BsonType.String)
    {
      this.IncludeLength = includeLength;
    }
  }
}
