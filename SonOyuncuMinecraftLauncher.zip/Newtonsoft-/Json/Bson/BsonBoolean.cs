﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Bson.BsonBoolean
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json.Bson
{
  internal class BsonBoolean : BsonValue
  {
    public static readonly BsonBoolean False = new BsonBoolean(false);
    public static readonly BsonBoolean True = new BsonBoolean(true);

    private BsonBoolean(bool value)
      : base((object) value, BsonType.Boolean)
    {
    }
  }
}
