﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Required
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json
{
  public enum Required
  {
    Default,
    AllowNull,
    Always,
    DisallowNull,
  }
}
