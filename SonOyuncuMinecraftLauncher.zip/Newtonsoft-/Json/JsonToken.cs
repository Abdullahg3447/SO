﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.JsonToken
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json
{
  public enum JsonToken
  {
    None,
    StartObject,
    StartArray,
    StartConstructor,
    PropertyName,
    Comment,
    Raw,
    Integer,
    Float,
    String,
    Boolean,
    Null,
    Undefined,
    EndObject,
    EndArray,
    EndConstructor,
    Date,
    Bytes,
  }
}
