﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Serialization.DefaultSerializationBinder
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Runtime.Serialization;

namespace Newtonsoft.Json.Serialization
{
  public class DefaultSerializationBinder : SerializationBinder, ISerializationBinder
  {
    internal static readonly DefaultSerializationBinder Instance = new DefaultSerializationBinder();
    private readonly ThreadSafeStore<TypeNameKey, Type> _typeCache;

    public DefaultSerializationBinder()
    {
      // ISSUE: method pointer
      this._typeCache = new ThreadSafeStore<TypeNameKey, Type>(new Func<TypeNameKey, Type>((object) this, __methodptr(GetTypeFromTypeNameKey)));
    }

    private Type GetTypeFromTypeNameKey(TypeNameKey typeNameKey)
    {
      string assemblyName = typeNameKey.AssemblyName;
      string typeName = typeNameKey.TypeName;
      if (assemblyName == null)
        return Type.GetType(typeName);
      Assembly assembly1 = Assembly.LoadWithPartialName(assemblyName);
      if (Assembly.op_Equality(assembly1, (Assembly) null))
      {
        foreach (Assembly assembly2 in AppDomain.CurrentDomain.GetAssemblies())
        {
          if (assembly2.FullName == assemblyName || assembly2.GetName().Name == assemblyName)
          {
            assembly1 = assembly2;
            break;
          }
        }
      }
      if (Assembly.op_Equality(assembly1, (Assembly) null))
        throw new JsonSerializationException("Could not load assembly '{0}'.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) assemblyName));
      Type type = assembly1.GetType(typeName);
      if (Type.op_Equality(type, (Type) null))
      {
        if (typeName.IndexOf('`') >= 0)
        {
          try
          {
            type = this.GetGenericTypeFromTypeName(typeName, assembly1);
          }
          catch (Exception ex)
          {
            throw new JsonSerializationException("Could not find type '{0}' in assembly '{1}'.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) typeName, (object) assembly1.FullName), ex);
          }
        }
        if (Type.op_Equality(type, (Type) null))
          throw new JsonSerializationException("Could not find type '{0}' in assembly '{1}'.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) typeName, (object) assembly1.FullName));
      }
      return type;
    }

    private Type GetGenericTypeFromTypeName(string typeName, Assembly assembly)
    {
      Type type1 = (Type) null;
      int length = typeName.IndexOf('[');
      if (length >= 0)
      {
        string name = typeName.Substring(0, length);
        Type type2 = assembly.GetType(name);
        if (Type.op_Inequality(type2, (Type) null))
        {
          List<Type> typeList = new List<Type>();
          int num1 = 0;
          int startIndex = 0;
          int num2 = typeName.Length - 1;
          for (int index = length + 1; index < num2; ++index)
          {
            switch (typeName[index])
            {
              case '[':
                if (num1 == 0)
                  startIndex = index + 1;
                ++num1;
                break;
              case ']':
                --num1;
                if (num1 == 0)
                {
                  TypeNameKey typeNameKey = ReflectionUtils.SplitFullyQualifiedTypeName(typeName.Substring(startIndex, index - startIndex));
                  typeList.Add(this.GetTypeByName(typeNameKey));
                  break;
                }
                break;
            }
          }
          type1 = type2.MakeGenericType(typeList.ToArray());
        }
      }
      return type1;
    }

    private Type GetTypeByName(TypeNameKey typeNameKey)
    {
      return this._typeCache.Get(typeNameKey);
    }

    public override Type BindToType(string assemblyName, string typeName)
    {
      return this.GetTypeByName(new TypeNameKey(assemblyName, typeName));
    }

    public virtual void BindToName(
      Type serializedType,
      out string assemblyName,
      out string typeName)
    {
      assemblyName = serializedType.Assembly.FullName;
      typeName = serializedType.FullName;
    }
  }
}
