﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Serialization.NamingStrategy
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json.Serialization
{
  public abstract class NamingStrategy
  {
    public bool ProcessDictionaryKeys { get; set; }

    public bool ProcessExtensionDataNames { get; set; }

    public bool OverrideSpecifiedNames { get; set; }

    public virtual string GetPropertyName(string name, bool hasSpecifiedName)
    {
      return hasSpecifiedName && !this.OverrideSpecifiedNames ? name : this.ResolvePropertyName(name);
    }

    public virtual string GetExtensionDataName(string name)
    {
      return !this.ProcessExtensionDataNames ? name : this.ResolvePropertyName(name);
    }

    public virtual string GetDictionaryKey(string key)
    {
      return !this.ProcessDictionaryKeys ? key : this.ResolvePropertyName(key);
    }

    protected abstract string ResolvePropertyName(string name);
  }
}
