﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Serialization.DiagnosticsTraceWriter
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Diagnostics;
using System.Threading;

namespace Newtonsoft.Json.Serialization
{
  public class DiagnosticsTraceWriter : ITraceWriter
  {
    public TraceLevel LevelFilter { get; set; }

    private TraceEventType GetTraceEventType(TraceLevel level)
    {
      switch (level)
      {
        case TraceLevel.Error:
          return TraceEventType.Error;
        case TraceLevel.Warning:
          return TraceEventType.Warning;
        case TraceLevel.Info:
          return TraceEventType.Information;
        case TraceLevel.Verbose:
          return TraceEventType.Verbose;
        default:
          throw new ArgumentOutOfRangeException(nameof (level));
      }
    }

    public void Trace(TraceLevel level, string message, Exception ex)
    {
      if (level == TraceLevel.Off)
        return;
      TraceEventCache eventCache = new TraceEventCache();
      TraceEventType traceEventType = this.GetTraceEventType(level);
      foreach (TraceListener listener in System.Diagnostics.Trace.Listeners)
      {
        if (!listener.IsThreadSafe)
        {
          TraceListener traceListener = listener;
          bool flag = false;
          try
          {
            Monitor.Enter((object) traceListener, ref flag);
            listener.TraceEvent(eventCache, "Newtonsoft.Json", traceEventType, 0, message);
          }
          finally
          {
            if (flag)
              Monitor.Exit((object) traceListener);
          }
        }
        else
          listener.TraceEvent(eventCache, "Newtonsoft.Json", traceEventType, 0, message);
        if (System.Diagnostics.Trace.AutoFlush)
          listener.Flush();
      }
    }
  }
}
