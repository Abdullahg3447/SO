﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Serialization.JsonTypeReflector
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Utilities;
using System;
using System.ComponentModel;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Permissions;

namespace Newtonsoft.Json.Serialization
{
  internal static class JsonTypeReflector
  {
    private static readonly ThreadSafeStore<Type, Func<object[], object>> CreatorCache = new ThreadSafeStore<Type, Func<object[], object>>(new Func<Type, Func<object[], object>>((object) null, __methodptr(GetCreator)));
    private static readonly ThreadSafeStore<Type, Type> AssociatedMetadataTypesCache = new ThreadSafeStore<Type, Type>(new Func<Type, Type>((object) null, __methodptr(GetAssociateMetadataTypeFromAttribute)));
    private static bool? _dynamicCodeGeneration;
    private static bool? _fullyTrusted;
    public const string IdPropertyName = "$id";
    public const string RefPropertyName = "$ref";
    public const string TypePropertyName = "$type";
    public const string ValuePropertyName = "$value";
    public const string ArrayValuesPropertyName = "$values";
    public const string ShouldSerializePrefix = "ShouldSerialize";
    public const string SpecifiedPostfix = "Specified";
    private static ReflectionObject _metadataTypeAttributeReflectionObject;

    public static T GetCachedAttribute<T>(object attributeProvider) where T : Attribute
    {
      return CachedAttributeGetter<T>.GetAttribute(attributeProvider);
    }

    public static bool CanTypeDescriptorConvertString(Type type, out TypeConverter typeConverter)
    {
      typeConverter = TypeDescriptor.GetConverter(type);
      if (typeConverter != null)
      {
        Type type1 = typeConverter.GetType();
        if (!string.Equals(type1.FullName, "System.ComponentModel.ComponentConverter", StringComparison.Ordinal) && !string.Equals(type1.FullName, "System.ComponentModel.ReferenceConverter", StringComparison.Ordinal) && (!string.Equals(type1.FullName, "System.Windows.Forms.Design.DataSourceConverter", StringComparison.Ordinal) && Type.op_Inequality(type1, typeof (TypeConverter))))
          return typeConverter.CanConvertTo(typeof (string));
      }
      return false;
    }

    public static DataContractAttribute GetDataContractAttribute(Type type)
    {
      for (Type type1 = type; Type.op_Inequality(type1, (Type) null); type1 = type1.BaseType())
      {
        DataContractAttribute attribute = CachedAttributeGetter<DataContractAttribute>.GetAttribute((object) type1);
        if (attribute != null)
          return attribute;
      }
      return (DataContractAttribute) null;
    }

    public static DataMemberAttribute GetDataMemberAttribute(
      MemberInfo memberInfo)
    {
      if (memberInfo.MemberType() == MemberTypes.Field)
        return CachedAttributeGetter<DataMemberAttribute>.GetAttribute((object) memberInfo);
      PropertyInfo propertyInfo = (PropertyInfo) memberInfo;
      DataMemberAttribute attribute = CachedAttributeGetter<DataMemberAttribute>.GetAttribute((object) propertyInfo);
      if (attribute == null && propertyInfo.IsVirtual())
      {
        for (Type type = propertyInfo.DeclaringType; attribute == null && Type.op_Inequality(type, (Type) null); type = type.BaseType())
        {
          PropertyInfo memberInfoFromType = (PropertyInfo) ReflectionUtils.GetMemberInfoFromType(type, (MemberInfo) propertyInfo);
          if (PropertyInfo.op_Inequality(memberInfoFromType, (PropertyInfo) null) && memberInfoFromType.IsVirtual())
            attribute = CachedAttributeGetter<DataMemberAttribute>.GetAttribute((object) memberInfoFromType);
        }
      }
      return attribute;
    }

    public static MemberSerialization GetObjectMemberSerialization(
      Type objectType,
      bool ignoreSerializableAttribute)
    {
      JsonObjectAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonObjectAttribute>((object) objectType);
      if (cachedAttribute != null)
        return cachedAttribute.MemberSerialization;
      if (JsonTypeReflector.GetDataContractAttribute(objectType) != null)
        return MemberSerialization.OptIn;
      return !ignoreSerializableAttribute && JsonTypeReflector.IsSerializable((object) objectType) ? MemberSerialization.Fields : MemberSerialization.OptOut;
    }

    public static JsonConverter GetJsonConverter(object attributeProvider)
    {
      JsonConverterAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonConverterAttribute>(attributeProvider);
      if (cachedAttribute != null)
      {
        Func<object[], object> func = JsonTypeReflector.CreatorCache.Get(cachedAttribute.ConverterType);
        if (func != null)
          return (JsonConverter) func.Invoke(cachedAttribute.ConverterParameters);
      }
      return (JsonConverter) null;
    }

    public static JsonConverter CreateJsonConverterInstance(
      Type converterType,
      object[] converterArgs)
    {
      return (JsonConverter) JsonTypeReflector.CreatorCache.Get(converterType).Invoke(converterArgs);
    }

    public static NamingStrategy CreateNamingStrategyInstance(
      Type namingStrategyType,
      object[] converterArgs)
    {
      return (NamingStrategy) JsonTypeReflector.CreatorCache.Get(namingStrategyType).Invoke(converterArgs);
    }

    public static NamingStrategy GetContainerNamingStrategy(
      JsonContainerAttribute containerAttribute)
    {
      if (containerAttribute.NamingStrategyInstance == null)
      {
        if (Type.op_Equality(containerAttribute.NamingStrategyType, (Type) null))
          return (NamingStrategy) null;
        containerAttribute.NamingStrategyInstance = JsonTypeReflector.CreateNamingStrategyInstance(containerAttribute.NamingStrategyType, containerAttribute.NamingStrategyParameters);
      }
      return containerAttribute.NamingStrategyInstance;
    }

    private static Func<object[], object> GetCreator(Type type)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      JsonTypeReflector.\u003C\u003Ec__DisplayClass21_0 cDisplayClass210 = new JsonTypeReflector.\u003C\u003Ec__DisplayClass21_0()
      {
        type = type
      };
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      cDisplayClass210.defaultConstructor = ReflectionUtils.HasDefaultConstructor(cDisplayClass210.type, false) ? JsonTypeReflector.ReflectionDelegateFactory.CreateDefaultConstructor<object>(cDisplayClass210.type) : (Func<object>) null;
      // ISSUE: method pointer
      return new Func<object[], object>((object) cDisplayClass210, __methodptr(\u003CGetCreator\u003Eb__0));
    }

    private static Type GetAssociatedMetadataType(Type type)
    {
      return JsonTypeReflector.AssociatedMetadataTypesCache.Get(type);
    }

    private static Type GetAssociateMetadataTypeFromAttribute(Type type)
    {
      foreach (Attribute attribute in ReflectionUtils.GetAttributes((object) type, (Type) null, true))
      {
        Type type1 = attribute.GetType();
        if (string.Equals(type1.FullName, "System.ComponentModel.DataAnnotations.MetadataTypeAttribute", StringComparison.Ordinal))
        {
          if (JsonTypeReflector._metadataTypeAttributeReflectionObject == null)
            JsonTypeReflector._metadataTypeAttributeReflectionObject = ReflectionObject.Create(type1, "MetadataClassType");
          return (Type) JsonTypeReflector._metadataTypeAttributeReflectionObject.GetValue((object) attribute, "MetadataClassType");
        }
      }
      return (Type) null;
    }

    private static T GetAttribute<T>(Type type) where T : Attribute
    {
      Type associatedMetadataType = JsonTypeReflector.GetAssociatedMetadataType(type);
      if (Type.op_Inequality(associatedMetadataType, (Type) null))
      {
        T attribute = ReflectionUtils.GetAttribute<T>((object) associatedMetadataType, true);
        if ((object) attribute != null)
          return attribute;
      }
      T attribute1 = ReflectionUtils.GetAttribute<T>((object) type, true);
      if ((object) attribute1 != null)
        return attribute1;
      foreach (object attributeProvider in type.GetInterfaces())
      {
        T attribute2 = ReflectionUtils.GetAttribute<T>(attributeProvider, true);
        if ((object) attribute2 != null)
          return attribute2;
      }
      return default (T);
    }

    private static T GetAttribute<T>(MemberInfo memberInfo) where T : Attribute
    {
      Type associatedMetadataType = JsonTypeReflector.GetAssociatedMetadataType(memberInfo.DeclaringType);
      if (Type.op_Inequality(associatedMetadataType, (Type) null))
      {
        MemberInfo memberInfoFromType = ReflectionUtils.GetMemberInfoFromType(associatedMetadataType, memberInfo);
        if (MemberInfo.op_Inequality(memberInfoFromType, (MemberInfo) null))
        {
          T attribute = ReflectionUtils.GetAttribute<T>((object) memberInfoFromType, true);
          if ((object) attribute != null)
            return attribute;
        }
      }
      T attribute1 = ReflectionUtils.GetAttribute<T>((object) memberInfo, true);
      if ((object) attribute1 != null)
        return attribute1;
      if (Type.op_Inequality(memberInfo.DeclaringType, (Type) null))
      {
        foreach (Type targetType in memberInfo.DeclaringType.GetInterfaces())
        {
          MemberInfo memberInfoFromType = ReflectionUtils.GetMemberInfoFromType(targetType, memberInfo);
          if (MemberInfo.op_Inequality(memberInfoFromType, (MemberInfo) null))
          {
            T attribute2 = ReflectionUtils.GetAttribute<T>((object) memberInfoFromType, true);
            if ((object) attribute2 != null)
              return attribute2;
          }
        }
      }
      return default (T);
    }

    public static bool IsNonSerializable(object provider)
    {
      return JsonTypeReflector.GetCachedAttribute<NonSerializedAttribute>(provider) != null;
    }

    public static bool IsSerializable(object provider)
    {
      return JsonTypeReflector.GetCachedAttribute<SerializableAttribute>(provider) != null;
    }

    public static T GetAttribute<T>(object provider) where T : Attribute
    {
      Type type = provider as Type;
      if (Type.op_Inequality(type, (Type) null))
        return JsonTypeReflector.GetAttribute<T>(type);
      MemberInfo memberInfo = provider as MemberInfo;
      return MemberInfo.op_Inequality(memberInfo, (MemberInfo) null) ? JsonTypeReflector.GetAttribute<T>(memberInfo) : ReflectionUtils.GetAttribute<T>(provider, true);
    }

    public static bool DynamicCodeGeneration
    {
      [SecuritySafeCritical] get
      {
        if (!JsonTypeReflector._dynamicCodeGeneration.HasValue)
        {
          try
          {
            new ReflectionPermission(ReflectionPermissionFlag.MemberAccess).Demand();
            new ReflectionPermission(ReflectionPermissionFlag.RestrictedMemberAccess).Demand();
            new SecurityPermission(SecurityPermissionFlag.SkipVerification).Demand();
            new SecurityPermission(SecurityPermissionFlag.UnmanagedCode).Demand();
            new SecurityPermission(PermissionState.Unrestricted).Demand();
            JsonTypeReflector._dynamicCodeGeneration = new bool?(true);
          }
          catch (Exception ex)
          {
            JsonTypeReflector._dynamicCodeGeneration = new bool?(false);
          }
        }
        return JsonTypeReflector._dynamicCodeGeneration.GetValueOrDefault();
      }
    }

    public static bool FullyTrusted
    {
      get
      {
        if (!JsonTypeReflector._fullyTrusted.HasValue)
        {
          AppDomain currentDomain = AppDomain.CurrentDomain;
          JsonTypeReflector._fullyTrusted = new bool?(currentDomain.get_IsHomogenous() && currentDomain.get_IsFullyTrusted());
        }
        return JsonTypeReflector._fullyTrusted.GetValueOrDefault();
      }
    }

    public static ReflectionDelegateFactory ReflectionDelegateFactory
    {
      get
      {
        return JsonTypeReflector.DynamicCodeGeneration ? (ReflectionDelegateFactory) DynamicReflectionDelegateFactory.Instance : LateBoundReflectionDelegateFactory.Instance;
      }
    }
  }
}
