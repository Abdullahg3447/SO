﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Serialization.SerializationBinderAdapter
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json.Serialization
{
  internal class SerializationBinderAdapter : ISerializationBinder
  {
    public readonly SerializationBinder SerializationBinder;

    public SerializationBinderAdapter(SerializationBinder serializationBinder)
    {
      this.SerializationBinder = serializationBinder;
    }

    public Type BindToType(string assemblyName, string typeName)
    {
      return this.SerializationBinder.BindToType(assemblyName, typeName);
    }

    public void BindToName(Type serializedType, out string assemblyName, out string typeName)
    {
      this.SerializationBinder.BindToName(serializedType, ref assemblyName, ref typeName);
    }
  }
}
