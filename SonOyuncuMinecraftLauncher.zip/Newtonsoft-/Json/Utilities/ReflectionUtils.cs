﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Utilities.ReflectionUtils
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Serialization;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;

namespace Newtonsoft.Json.Utilities
{
  internal static class ReflectionUtils
  {
    public static readonly Type[] EmptyTypes = Type.EmptyTypes;

    public static bool IsVirtual(this PropertyInfo propertyInfo)
    {
      ValidationUtils.ArgumentNotNull((object) propertyInfo, nameof (propertyInfo));
      MethodInfo getMethod = propertyInfo.GetGetMethod(true);
      if (MethodInfo.op_Inequality(getMethod, (MethodInfo) null) && getMethod.IsVirtual)
        return true;
      MethodInfo setMethod = propertyInfo.GetSetMethod(true);
      return MethodInfo.op_Inequality(setMethod, (MethodInfo) null) && setMethod.IsVirtual;
    }

    public static MethodInfo GetBaseDefinition(this PropertyInfo propertyInfo)
    {
      ValidationUtils.ArgumentNotNull((object) propertyInfo, nameof (propertyInfo));
      MethodInfo getMethod = propertyInfo.GetGetMethod(true);
      if (MethodInfo.op_Inequality(getMethod, (MethodInfo) null))
        return getMethod.GetBaseDefinition();
      return propertyInfo.GetSetMethod(true)?.GetBaseDefinition();
    }

    public static bool IsPublic(PropertyInfo property)
    {
      return MethodInfo.op_Inequality(property.GetGetMethod(), (MethodInfo) null) && property.GetGetMethod().IsPublic || MethodInfo.op_Inequality(property.GetSetMethod(), (MethodInfo) null) && property.GetSetMethod().IsPublic;
    }

    public static Type GetObjectType(object v)
    {
      return v?.GetType();
    }

    public static string GetTypeName(
      Type t,
      TypeNameAssemblyFormatHandling assemblyFormat,
      ISerializationBinder binder)
    {
      string qualifiedTypeName = ReflectionUtils.GetFullyQualifiedTypeName(t, binder);
      if (assemblyFormat == TypeNameAssemblyFormatHandling.Simple)
        return ReflectionUtils.RemoveAssemblyDetails(qualifiedTypeName);
      if (assemblyFormat == TypeNameAssemblyFormatHandling.Full)
        return qualifiedTypeName;
      throw new ArgumentOutOfRangeException();
    }

    private static string GetFullyQualifiedTypeName(Type t, ISerializationBinder binder)
    {
      if (binder == null)
        return t.AssemblyQualifiedName;
      string assemblyName;
      string typeName;
      binder.BindToName(t, out assemblyName, out typeName);
      return typeName + (assemblyName == null ? "" : ", " + assemblyName);
    }

    private static string RemoveAssemblyDetails(string fullyQualifiedTypeName)
    {
      StringBuilder stringBuilder = new StringBuilder();
      bool flag1 = false;
      bool flag2 = false;
      for (int index = 0; index < fullyQualifiedTypeName.Length; ++index)
      {
        char ch = fullyQualifiedTypeName[index];
        switch (ch)
        {
          case ',':
            if (!flag1)
            {
              flag1 = true;
              stringBuilder.Append(ch);
              break;
            }
            flag2 = true;
            break;
          case '[':
            flag1 = false;
            flag2 = false;
            stringBuilder.Append(ch);
            break;
          case ']':
            flag1 = false;
            flag2 = false;
            stringBuilder.Append(ch);
            break;
          default:
            if (!flag2)
            {
              stringBuilder.Append(ch);
              break;
            }
            break;
        }
      }
      return stringBuilder.ToString();
    }

    public static bool HasDefaultConstructor(Type t, bool nonPublic)
    {
      ValidationUtils.ArgumentNotNull((object) t, nameof (t));
      return t.IsValueType() || ConstructorInfo.op_Inequality(ReflectionUtils.GetDefaultConstructor(t, nonPublic), (ConstructorInfo) null);
    }

    public static ConstructorInfo GetDefaultConstructor(Type t)
    {
      return ReflectionUtils.GetDefaultConstructor(t, false);
    }

    public static ConstructorInfo GetDefaultConstructor(Type t, bool nonPublic)
    {
      BindingFlags bindingAttr = BindingFlags.Instance | BindingFlags.Public;
      if (nonPublic)
        bindingAttr |= BindingFlags.NonPublic;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return (ConstructorInfo) Enumerable.SingleOrDefault<ConstructorInfo>((IEnumerable<M0>) t.GetConstructors(bindingAttr), (Func<M0, bool>) (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__11_0 ?? (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__11_0 = new Func<ConstructorInfo, bool>((object) ReflectionUtils.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CGetDefaultConstructor\u003Eb__11_0)))));
    }

    public static bool IsNullable(Type t)
    {
      ValidationUtils.ArgumentNotNull((object) t, nameof (t));
      return !t.IsValueType() || ReflectionUtils.IsNullableType(t);
    }

    public static bool IsNullableType(Type t)
    {
      ValidationUtils.ArgumentNotNull((object) t, nameof (t));
      return t.IsGenericType() && Type.op_Equality(t.GetGenericTypeDefinition(), typeof (Nullable<>));
    }

    public static Type EnsureNotNullableType(Type t)
    {
      return !ReflectionUtils.IsNullableType(t) ? t : Nullable.GetUnderlyingType(t);
    }

    public static bool IsGenericDefinition(Type type, Type genericInterfaceDefinition)
    {
      return type.IsGenericType() && Type.op_Equality(type.GetGenericTypeDefinition(), genericInterfaceDefinition);
    }

    public static bool ImplementsGenericDefinition(Type type, Type genericInterfaceDefinition)
    {
      return ReflectionUtils.ImplementsGenericDefinition(type, genericInterfaceDefinition, out Type _);
    }

    public static bool ImplementsGenericDefinition(
      Type type,
      Type genericInterfaceDefinition,
      out Type implementingType)
    {
      ValidationUtils.ArgumentNotNull((object) type, nameof (type));
      ValidationUtils.ArgumentNotNull((object) genericInterfaceDefinition, nameof (genericInterfaceDefinition));
      if (!genericInterfaceDefinition.IsInterface() || !genericInterfaceDefinition.IsGenericTypeDefinition())
        throw new ArgumentNullException("'{0}' is not a generic interface definition.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) genericInterfaceDefinition));
      if (type.IsInterface() && type.IsGenericType())
      {
        Type genericTypeDefinition = type.GetGenericTypeDefinition();
        if (Type.op_Equality(genericInterfaceDefinition, genericTypeDefinition))
        {
          implementingType = type;
          return true;
        }
      }
      foreach (Type type1 in type.GetInterfaces())
      {
        if (type1.IsGenericType())
        {
          Type genericTypeDefinition = type1.GetGenericTypeDefinition();
          if (Type.op_Equality(genericInterfaceDefinition, genericTypeDefinition))
          {
            implementingType = type1;
            return true;
          }
        }
      }
      implementingType = (Type) null;
      return false;
    }

    public static bool InheritsGenericDefinition(Type type, Type genericClassDefinition)
    {
      return ReflectionUtils.InheritsGenericDefinition(type, genericClassDefinition, out Type _);
    }

    public static bool InheritsGenericDefinition(
      Type type,
      Type genericClassDefinition,
      out Type implementingType)
    {
      ValidationUtils.ArgumentNotNull((object) type, nameof (type));
      ValidationUtils.ArgumentNotNull((object) genericClassDefinition, nameof (genericClassDefinition));
      if (!genericClassDefinition.IsClass() || !genericClassDefinition.IsGenericTypeDefinition())
        throw new ArgumentNullException("'{0}' is not a generic class definition.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) genericClassDefinition));
      return ReflectionUtils.InheritsGenericDefinitionInternal(type, genericClassDefinition, out implementingType);
    }

    private static bool InheritsGenericDefinitionInternal(
      Type currentType,
      Type genericClassDefinition,
      out Type implementingType)
    {
      if (currentType.IsGenericType())
      {
        Type genericTypeDefinition = currentType.GetGenericTypeDefinition();
        if (Type.op_Equality(genericClassDefinition, genericTypeDefinition))
        {
          implementingType = currentType;
          return true;
        }
      }
      if (!Type.op_Equality(currentType.BaseType(), (Type) null))
        return ReflectionUtils.InheritsGenericDefinitionInternal(currentType.BaseType(), genericClassDefinition, out implementingType);
      implementingType = (Type) null;
      return false;
    }

    public static Type GetCollectionItemType(Type type)
    {
      ValidationUtils.ArgumentNotNull((object) type, nameof (type));
      if (type.IsArray)
        return type.GetElementType();
      Type implementingType;
      if (ReflectionUtils.ImplementsGenericDefinition(type, typeof (IEnumerable<>), out implementingType))
      {
        if (implementingType.IsGenericTypeDefinition())
          throw new Exception("Type {0} is not a collection.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) type));
        return implementingType.GetGenericArguments()[0];
      }
      if (typeof (IEnumerable).IsAssignableFrom(type))
        return (Type) null;
      throw new Exception("Type {0} is not a collection.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) type));
    }

    public static void GetDictionaryKeyValueTypes(
      Type dictionaryType,
      out Type keyType,
      out Type valueType)
    {
      ValidationUtils.ArgumentNotNull((object) dictionaryType, nameof (dictionaryType));
      Type implementingType;
      if (ReflectionUtils.ImplementsGenericDefinition(dictionaryType, typeof (IDictionary<,>), out implementingType))
      {
        if (implementingType.IsGenericTypeDefinition())
          throw new Exception("Type {0} is not a dictionary.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) dictionaryType));
        Type[] genericArguments = implementingType.GetGenericArguments();
        keyType = genericArguments[0];
        valueType = genericArguments[1];
      }
      else
      {
        if (!typeof (IDictionary).IsAssignableFrom(dictionaryType))
          throw new Exception("Type {0} is not a dictionary.".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) dictionaryType));
        keyType = (Type) null;
        valueType = (Type) null;
      }
    }

    public static Type GetMemberUnderlyingType(MemberInfo member)
    {
      ValidationUtils.ArgumentNotNull((object) member, nameof (member));
      switch (member.MemberType())
      {
        case MemberTypes.Event:
          return ((EventInfo) member).EventHandlerType;
        case MemberTypes.Field:
          return ((FieldInfo) member).FieldType;
        case MemberTypes.Method:
          return ((MethodInfo) member).ReturnType;
        case MemberTypes.Property:
          return ((PropertyInfo) member).PropertyType;
        default:
          throw new ArgumentException("MemberInfo must be of type FieldInfo, PropertyInfo, EventInfo or MethodInfo", nameof (member));
      }
    }

    public static bool IsIndexedProperty(MemberInfo member)
    {
      ValidationUtils.ArgumentNotNull((object) member, nameof (member));
      PropertyInfo property = member as PropertyInfo;
      return PropertyInfo.op_Inequality(property, (PropertyInfo) null) && ReflectionUtils.IsIndexedProperty(property);
    }

    public static bool IsIndexedProperty(PropertyInfo property)
    {
      ValidationUtils.ArgumentNotNull((object) property, nameof (property));
      return (uint) property.GetIndexParameters().Length > 0U;
    }

    public static object GetMemberValue(MemberInfo member, object target)
    {
      ValidationUtils.ArgumentNotNull((object) member, nameof (member));
      ValidationUtils.ArgumentNotNull(target, nameof (target));
      switch (member.MemberType())
      {
        case MemberTypes.Field:
          return ((FieldInfo) member).GetValue(target);
        case MemberTypes.Property:
          try
          {
            return ((PropertyInfo) member).GetValue(target, (object[]) null);
          }
          catch (TargetParameterCountException ex)
          {
            throw new ArgumentException("MemberInfo '{0}' has index parameters".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) member.Name), (Exception) ex);
          }
        default:
          throw new ArgumentException("MemberInfo '{0}' is not of type FieldInfo or PropertyInfo".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) member.Name), nameof (member));
      }
    }

    public static void SetMemberValue(MemberInfo member, object target, object value)
    {
      ValidationUtils.ArgumentNotNull((object) member, nameof (member));
      ValidationUtils.ArgumentNotNull(target, nameof (target));
      switch (member.MemberType())
      {
        case MemberTypes.Field:
          ((FieldInfo) member).SetValue(target, value);
          break;
        case MemberTypes.Property:
          ((PropertyInfo) member).SetValue(target, value, (object[]) null);
          break;
        default:
          throw new ArgumentException("MemberInfo '{0}' must be of type FieldInfo or PropertyInfo".FormatWith((IFormatProvider) CultureInfo.InvariantCulture, (object) member.Name), nameof (member));
      }
    }

    public static bool CanReadMemberValue(MemberInfo member, bool nonPublic)
    {
      switch (member.MemberType())
      {
        case MemberTypes.Field:
          FieldInfo fieldInfo = (FieldInfo) member;
          return nonPublic || fieldInfo.IsPublic;
        case MemberTypes.Property:
          PropertyInfo propertyInfo = (PropertyInfo) member;
          if (!propertyInfo.CanRead)
            return false;
          return nonPublic || MethodInfo.op_Inequality(propertyInfo.GetGetMethod(nonPublic), (MethodInfo) null);
        default:
          return false;
      }
    }

    public static bool CanSetMemberValue(MemberInfo member, bool nonPublic, bool canSetReadOnly)
    {
      switch (member.MemberType())
      {
        case MemberTypes.Field:
          FieldInfo fieldInfo = (FieldInfo) member;
          return !fieldInfo.IsLiteral && (!fieldInfo.IsInitOnly || canSetReadOnly) && (nonPublic || fieldInfo.IsPublic);
        case MemberTypes.Property:
          PropertyInfo propertyInfo = (PropertyInfo) member;
          if (!propertyInfo.CanWrite)
            return false;
          return nonPublic || MethodInfo.op_Inequality(propertyInfo.GetSetMethod(nonPublic), (MethodInfo) null);
        default:
          return false;
      }
    }

    public static List<MemberInfo> GetFieldsAndProperties(
      Type type,
      BindingFlags bindingAttr)
    {
      List<MemberInfo> memberInfoList1 = new List<MemberInfo>();
      memberInfoList1.AddRange((IEnumerable<MemberInfo>) ReflectionUtils.GetFields(type, bindingAttr));
      memberInfoList1.AddRange((IEnumerable<MemberInfo>) ReflectionUtils.GetProperties(type, bindingAttr));
      List<MemberInfo> memberInfoList2 = new List<MemberInfo>(memberInfoList1.Count);
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      foreach (IGrouping<string, MemberInfo> source in (IEnumerable<IGrouping<string, MemberInfo>>) Enumerable.GroupBy<MemberInfo, string>((IEnumerable<M0>) memberInfoList1, (Func<M0, M1>) (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__30_0 ?? (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__30_0 = new Func<MemberInfo, string>((object) ReflectionUtils.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CGetFieldsAndProperties\u003Eb__30_0))))))
      {
        if (source.Count<MemberInfo>() == 1)
        {
          memberInfoList2.Add(source.First<MemberInfo>());
        }
        else
        {
          IList<MemberInfo> memberInfoList3 = (IList<MemberInfo>) new List<MemberInfo>();
          foreach (MemberInfo memberInfo in (IEnumerable<MemberInfo>) source)
          {
            if (memberInfoList3.Count == 0)
              memberInfoList3.Add(memberInfo);
            else if (!ReflectionUtils.IsOverridenGenericMember(memberInfo, bindingAttr) || memberInfo.Name == "Item")
              memberInfoList3.Add(memberInfo);
          }
          memberInfoList2.AddRange((IEnumerable<MemberInfo>) memberInfoList3);
        }
      }
      return memberInfoList2;
    }

    private static bool IsOverridenGenericMember(MemberInfo memberInfo, BindingFlags bindingAttr)
    {
      if (memberInfo.MemberType() != MemberTypes.Property)
        return false;
      PropertyInfo propertyInfo = (PropertyInfo) memberInfo;
      if (!propertyInfo.IsVirtual())
        return false;
      Type declaringType = propertyInfo.DeclaringType;
      if (!declaringType.IsGenericType())
        return false;
      Type genericTypeDefinition = declaringType.GetGenericTypeDefinition();
      if (Type.op_Equality(genericTypeDefinition, (Type) null))
        return false;
      MemberInfo[] member = genericTypeDefinition.GetMember(propertyInfo.Name, bindingAttr);
      return member.Length != 0 && ReflectionUtils.GetMemberUnderlyingType(member[0]).IsGenericParameter;
    }

    public static T GetAttribute<T>(object attributeProvider) where T : Attribute
    {
      return ReflectionUtils.GetAttribute<T>(attributeProvider, true);
    }

    public static T GetAttribute<T>(object attributeProvider, bool inherit) where T : Attribute
    {
      T[] attributes = ReflectionUtils.GetAttributes<T>(attributeProvider, inherit);
      return attributes == null ? default (T) : ((IEnumerable<T>) attributes).FirstOrDefault<T>();
    }

    public static T[] GetAttributes<T>(object attributeProvider, bool inherit) where T : Attribute
    {
      Attribute[] attributes = ReflectionUtils.GetAttributes(attributeProvider, typeof (T), inherit);
      return attributes is T[] objArray ? objArray : attributes.Cast<T>().ToArray<T>();
    }

    public static Attribute[] GetAttributes(
      object attributeProvider,
      Type attributeType,
      bool inherit)
    {
      ValidationUtils.ArgumentNotNull(attributeProvider, nameof (attributeProvider));
      object obj = attributeProvider;
      Type type = obj as Type;
      if (Type.op_Inequality(type, (Type) null))
        return (Type.op_Inequality(attributeType, (Type) null) ? (IEnumerable) type.GetCustomAttributes(attributeType, inherit) : (IEnumerable) type.GetCustomAttributes(inherit)).Cast<Attribute>().ToArray<Attribute>();
      Assembly element1 = obj as Assembly;
      if (Assembly.op_Inequality(element1, (Assembly) null))
        return !Type.op_Inequality(attributeType, (Type) null) ? Attribute.GetCustomAttributes(element1) : Attribute.GetCustomAttributes(element1, attributeType);
      MemberInfo element2 = obj as MemberInfo;
      if (MemberInfo.op_Inequality(element2, (MemberInfo) null))
        return !Type.op_Inequality(attributeType, (Type) null) ? Attribute.GetCustomAttributes(element2, inherit) : Attribute.GetCustomAttributes(element2, attributeType, inherit);
      Module element3 = obj as Module;
      if (Module.op_Inequality(element3, (Module) null))
        return !Type.op_Inequality(attributeType, (Type) null) ? Attribute.GetCustomAttributes(element3, inherit) : Attribute.GetCustomAttributes(element3, attributeType, inherit);
      if (obj is ParameterInfo element4)
        return !Type.op_Inequality(attributeType, (Type) null) ? Attribute.GetCustomAttributes(element4, inherit) : Attribute.GetCustomAttributes(element4, attributeType, inherit);
      ICustomAttributeProvider attributeProvider1 = (ICustomAttributeProvider) attributeProvider;
      return Type.op_Inequality(attributeType, (Type) null) ? (Attribute[]) attributeProvider1.GetCustomAttributes(attributeType, inherit) : (Attribute[]) attributeProvider1.GetCustomAttributes(inherit);
    }

    public static TypeNameKey SplitFullyQualifiedTypeName(string fullyQualifiedTypeName)
    {
      int? assemblyDelimiterIndex = ReflectionUtils.GetAssemblyDelimiterIndex(fullyQualifiedTypeName);
      string typeName;
      string assemblyName;
      if (assemblyDelimiterIndex.HasValue)
      {
        typeName = fullyQualifiedTypeName.Trim(0, assemblyDelimiterIndex.GetValueOrDefault());
        assemblyName = fullyQualifiedTypeName.Trim(assemblyDelimiterIndex.GetValueOrDefault() + 1, fullyQualifiedTypeName.Length - assemblyDelimiterIndex.GetValueOrDefault() - 1);
      }
      else
      {
        typeName = fullyQualifiedTypeName;
        assemblyName = (string) null;
      }
      return new TypeNameKey(assemblyName, typeName);
    }

    private static int? GetAssemblyDelimiterIndex(string fullyQualifiedTypeName)
    {
      int num = 0;
      for (int index = 0; index < fullyQualifiedTypeName.Length; ++index)
      {
        switch (fullyQualifiedTypeName[index])
        {
          case ',':
            if (num == 0)
              return new int?(index);
            break;
          case '[':
            ++num;
            break;
          case ']':
            --num;
            break;
        }
      }
      return new int?();
    }

    public static MemberInfo GetMemberInfoFromType(Type targetType, MemberInfo memberInfo)
    {
      if (memberInfo.MemberType() != MemberTypes.Property)
        return ((IEnumerable<MemberInfo>) targetType.GetMember(memberInfo.Name, memberInfo.MemberType(), BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)).SingleOrDefault<MemberInfo>();
      PropertyInfo propertyInfo = (PropertyInfo) memberInfo;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Type[] array = ((IEnumerable<Type>) Enumerable.Select<ParameterInfo, Type>((IEnumerable<M0>) propertyInfo.GetIndexParameters(), (Func<M0, M1>) (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__38_0 ?? (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__38_0 = new Func<ParameterInfo, Type>((object) ReflectionUtils.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CGetMemberInfoFromType\u003Eb__38_0)))))).ToArray<Type>();
      return (MemberInfo) targetType.GetProperty(propertyInfo.Name, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, (Binder) null, propertyInfo.PropertyType, array, (ParameterModifier[]) null);
    }

    public static IEnumerable<FieldInfo> GetFields(
      Type targetType,
      BindingFlags bindingAttr)
    {
      ValidationUtils.ArgumentNotNull((object) targetType, nameof (targetType));
      List<MemberInfo> source = new List<MemberInfo>((IEnumerable<MemberInfo>) targetType.GetFields(bindingAttr));
      ReflectionUtils.GetChildPrivateFields((IList<MemberInfo>) source, targetType, bindingAttr);
      return source.Cast<FieldInfo>();
    }

    private static void GetChildPrivateFields(
      IList<MemberInfo> initialFields,
      Type targetType,
      BindingFlags bindingAttr)
    {
      if ((bindingAttr & BindingFlags.NonPublic) == BindingFlags.Default)
        return;
      BindingFlags bindingAttr1 = bindingAttr.RemoveFlag(BindingFlags.Public);
      while (Type.op_Inequality(targetType = targetType.BaseType(), (Type) null))
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        IEnumerable<FieldInfo> fieldInfos = (IEnumerable<FieldInfo>) Enumerable.Where<FieldInfo>((IEnumerable<M0>) targetType.GetFields(bindingAttr1), (Func<M0, bool>) (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__40_0 ?? (ReflectionUtils.\u003C\u003Ec.\u003C\u003E9__40_0 = new Func<FieldInfo, bool>((object) ReflectionUtils.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CGetChildPrivateFields\u003Eb__40_0)))));
        initialFields.AddRange<MemberInfo>((IEnumerable<MemberInfo>) fieldInfos);
      }
    }

    public static IEnumerable<PropertyInfo> GetProperties(
      Type targetType,
      BindingFlags bindingAttr)
    {
      ValidationUtils.ArgumentNotNull((object) targetType, nameof (targetType));
      List<PropertyInfo> propertyInfoList = new List<PropertyInfo>((IEnumerable<PropertyInfo>) targetType.GetProperties(bindingAttr));
      if (targetType.IsInterface())
      {
        foreach (Type type in targetType.GetInterfaces())
          propertyInfoList.AddRange((IEnumerable<PropertyInfo>) type.GetProperties(bindingAttr));
      }
      ReflectionUtils.GetChildPrivateProperties((IList<PropertyInfo>) propertyInfoList, targetType, bindingAttr);
      for (int index = 0; index < propertyInfoList.Count; ++index)
      {
        PropertyInfo propertyInfo = propertyInfoList[index];
        if (Type.op_Inequality(propertyInfo.DeclaringType, targetType))
        {
          PropertyInfo memberInfoFromType = (PropertyInfo) ReflectionUtils.GetMemberInfoFromType(propertyInfo.DeclaringType, (MemberInfo) propertyInfo);
          propertyInfoList[index] = memberInfoFromType;
        }
      }
      return (IEnumerable<PropertyInfo>) propertyInfoList;
    }

    public static BindingFlags RemoveFlag(
      this BindingFlags bindingAttr,
      BindingFlags flag)
    {
      return (bindingAttr & flag) != flag ? bindingAttr : bindingAttr ^ flag;
    }

    private static void GetChildPrivateProperties(
      IList<PropertyInfo> initialProperties,
      Type targetType,
      BindingFlags bindingAttr)
    {
      while (Type.op_Inequality(targetType = targetType.BaseType(), (Type) null))
      {
        foreach (PropertyInfo property in targetType.GetProperties(bindingAttr))
        {
          // ISSUE: object of a compiler-generated type is created
          // ISSUE: variable of a compiler-generated type
          ReflectionUtils.\u003C\u003Ec__DisplayClass43_0 cDisplayClass430 = new ReflectionUtils.\u003C\u003Ec__DisplayClass43_0();
          // ISSUE: reference to a compiler-generated field
          cDisplayClass430.subTypeProperty = property;
          // ISSUE: reference to a compiler-generated field
          if (!cDisplayClass430.subTypeProperty.IsVirtual())
          {
            // ISSUE: reference to a compiler-generated field
            if (!ReflectionUtils.IsPublic(cDisplayClass430.subTypeProperty))
            {
              // ISSUE: method pointer
              int index = initialProperties.IndexOf<PropertyInfo>(new Func<PropertyInfo, bool>((object) cDisplayClass430, __methodptr(\u003CGetChildPrivateProperties\u003Eb__0)));
              if (index == -1)
              {
                // ISSUE: reference to a compiler-generated field
                initialProperties.Add(cDisplayClass430.subTypeProperty);
              }
              else if (!ReflectionUtils.IsPublic(initialProperties[index]))
              {
                // ISSUE: reference to a compiler-generated field
                initialProperties[index] = cDisplayClass430.subTypeProperty;
              }
            }
            else
            {
              // ISSUE: method pointer
              if (initialProperties.IndexOf<PropertyInfo>(new Func<PropertyInfo, bool>((object) cDisplayClass430, __methodptr(\u003CGetChildPrivateProperties\u003Eb__1))) == -1)
              {
                // ISSUE: reference to a compiler-generated field
                initialProperties.Add(cDisplayClass430.subTypeProperty);
              }
            }
          }
          else
          {
            // ISSUE: object of a compiler-generated type is created
            // ISSUE: variable of a compiler-generated type
            ReflectionUtils.\u003C\u003Ec__DisplayClass43_1 cDisplayClass431 = new ReflectionUtils.\u003C\u003Ec__DisplayClass43_1()
            {
              CS\u0024\u003C\u003E8__locals1 = cDisplayClass430
            };
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            cDisplayClass431.subTypePropertyDeclaringType = cDisplayClass431.CS\u0024\u003C\u003E8__locals1.subTypeProperty.GetBaseDefinition()?.DeclaringType ?? cDisplayClass431.CS\u0024\u003C\u003E8__locals1.subTypeProperty.DeclaringType;
            // ISSUE: method pointer
            if (initialProperties.IndexOf<PropertyInfo>(new Func<PropertyInfo, bool>((object) cDisplayClass431, __methodptr(\u003CGetChildPrivateProperties\u003Eb__2))) == -1)
            {
              // ISSUE: reference to a compiler-generated field
              // ISSUE: reference to a compiler-generated field
              initialProperties.Add(cDisplayClass431.CS\u0024\u003C\u003E8__locals1.subTypeProperty);
            }
          }
        }
      }
    }

    public static bool IsMethodOverridden(
      Type currentType,
      Type methodDeclaringType,
      string method)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: method pointer
      return Enumerable.Any<MethodInfo>((IEnumerable<M0>) currentType.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic), (Func<M0, bool>) new Func<MethodInfo, bool>((object) new ReflectionUtils.\u003C\u003Ec__DisplayClass44_0()
      {
        method = method,
        methodDeclaringType = methodDeclaringType
      }, __methodptr(\u003CIsMethodOverridden\u003Eb__0)));
    }

    public static object GetDefaultValue(Type type)
    {
      if (!type.IsValueType())
        return (object) null;
      switch (ConvertUtils.GetTypeCode(type))
      {
        case PrimitiveTypeCode.Char:
        case PrimitiveTypeCode.SByte:
        case PrimitiveTypeCode.Int16:
        case PrimitiveTypeCode.UInt16:
        case PrimitiveTypeCode.Int32:
        case PrimitiveTypeCode.Byte:
        case PrimitiveTypeCode.UInt32:
          return (object) 0;
        case PrimitiveTypeCode.Boolean:
          return (object) false;
        case PrimitiveTypeCode.Int64:
        case PrimitiveTypeCode.UInt64:
          return (object) 0L;
        case PrimitiveTypeCode.Single:
          return (object) 0.0f;
        case PrimitiveTypeCode.Double:
          return (object) 0.0;
        case PrimitiveTypeCode.DateTime:
          return (object) new DateTime();
        case PrimitiveTypeCode.DateTimeOffset:
          return (object) new DateTimeOffset();
        case PrimitiveTypeCode.Decimal:
          return (object) Decimal.Zero;
        case PrimitiveTypeCode.Guid:
          return (object) new Guid();
        case PrimitiveTypeCode.BigInteger:
          return (object) new BigInteger();
        default:
          return ReflectionUtils.IsNullable(type) ? (object) null : Activator.CreateInstance(type);
      }
    }
  }
}
