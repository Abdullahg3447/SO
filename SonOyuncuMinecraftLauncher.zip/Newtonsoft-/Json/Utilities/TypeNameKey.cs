﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Utilities.TypeNameKey
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;

namespace Newtonsoft.Json.Utilities
{
  internal struct TypeNameKey : IEquatable<TypeNameKey>
  {
    internal readonly string AssemblyName;
    internal readonly string TypeName;

    public TypeNameKey(string assemblyName, string typeName)
    {
      this.AssemblyName = assemblyName;
      this.TypeName = typeName;
    }

    public override int GetHashCode()
    {
      string assemblyName = this.AssemblyName;
      int num1 = assemblyName != null ? assemblyName.GetHashCode() : 0;
      string typeName = this.TypeName;
      int num2 = typeName != null ? typeName.GetHashCode() : 0;
      return num1 ^ num2;
    }

    public override bool Equals(object obj)
    {
      return obj is TypeNameKey other && this.Equals(other);
    }

    public bool Equals(TypeNameKey other)
    {
      return this.AssemblyName == other.AssemblyName && this.TypeName == other.TypeName;
    }
  }
}
