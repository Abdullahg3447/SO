﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Utilities.DynamicProxyMetaObject`1
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Linq.Expressions;

namespace Newtonsoft.Json.Utilities
{
  internal sealed class DynamicProxyMetaObject<T> : DynamicMetaObject
  {
    private readonly DynamicProxy<T> _proxy;

    internal DynamicProxyMetaObject(Expression expression, T value, DynamicProxy<T> proxy)
    {
      this.\u002Ector(expression, (BindingRestrictions) BindingRestrictions.Empty, (object) value);
      this._proxy = proxy;
    }

    private bool IsOverridden(string method)
    {
      return ReflectionUtils.IsMethodOverridden(this._proxy.GetType(), typeof (DynamicProxy<T>), method);
    }

    public virtual DynamicMetaObject BindGetMember(GetMemberBinder binder)
    {
      return !this.IsOverridden("TryGetMember") ? base.BindGetMember(binder) : this.CallMethodWithResult("TryGetMember", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.NoArgs, (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackGetMember((DynamicMetaObject) this, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindSetMember(
      SetMemberBinder binder,
      DynamicMetaObject value)
    {
      if (!this.IsOverridden("TrySetMember"))
        return base.BindSetMember(binder, value);
      return this.CallMethodReturnLast("TrySetMember", (DynamicMetaObjectBinder) binder, DynamicProxyMetaObject<T>.GetArgs(value), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackSetMember((DynamicMetaObject) this, value, e)));
    }

    public virtual DynamicMetaObject BindDeleteMember(DeleteMemberBinder binder)
    {
      return !this.IsOverridden("TryDeleteMember") ? base.BindDeleteMember(binder) : this.CallMethodNoResult("TryDeleteMember", (DynamicMetaObjectBinder) binder, DynamicProxyMetaObject<T>.NoArgs, (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackDeleteMember((DynamicMetaObject) this, e)));
    }

    public virtual DynamicMetaObject BindConvert(ConvertBinder binder)
    {
      return !this.IsOverridden("TryConvert") ? base.BindConvert(binder) : this.CallMethodWithResult("TryConvert", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.NoArgs, (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackConvert((DynamicMetaObject) this, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindInvokeMember(
      InvokeMemberBinder binder,
      DynamicMetaObject[] args)
    {
      if (!this.IsOverridden("TryInvokeMember"))
        return base.BindInvokeMember(binder, args);
      DynamicProxyMetaObject<T>.Fallback fallback = (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackInvokeMember((DynamicMetaObject) this, args, e));
      return this.BuildCallMethodWithResult("TryInvokeMember", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.GetArgArray(args), this.BuildCallMethodWithResult("TryGetMember", (DynamicMetaObjectBinder) new DynamicProxyMetaObject<T>.GetBinderAdapter(binder), (IEnumerable<Expression>) DynamicProxyMetaObject<T>.NoArgs, fallback((DynamicMetaObject) null), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackInvoke(e, args, (DynamicMetaObject) null))), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindCreateInstance(
      CreateInstanceBinder binder,
      DynamicMetaObject[] args)
    {
      return !this.IsOverridden("TryCreateInstance") ? base.BindCreateInstance(binder, args) : this.CallMethodWithResult("TryCreateInstance", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.GetArgArray(args), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackCreateInstance((DynamicMetaObject) this, args, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindInvoke(
      InvokeBinder binder,
      DynamicMetaObject[] args)
    {
      return !this.IsOverridden("TryInvoke") ? base.BindInvoke(binder, args) : this.CallMethodWithResult("TryInvoke", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.GetArgArray(args), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackInvoke((DynamicMetaObject) this, args, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindBinaryOperation(
      BinaryOperationBinder binder,
      DynamicMetaObject arg)
    {
      if (!this.IsOverridden("TryBinaryOperation"))
        return base.BindBinaryOperation(binder, arg);
      return this.CallMethodWithResult("TryBinaryOperation", (DynamicMetaObjectBinder) binder, DynamicProxyMetaObject<T>.GetArgs(arg), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackBinaryOperation((DynamicMetaObject) this, arg, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindUnaryOperation(UnaryOperationBinder binder)
    {
      return !this.IsOverridden("TryUnaryOperation") ? base.BindUnaryOperation(binder) : this.CallMethodWithResult("TryUnaryOperation", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.NoArgs, (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackUnaryOperation((DynamicMetaObject) this, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindGetIndex(
      GetIndexBinder binder,
      DynamicMetaObject[] indexes)
    {
      return !this.IsOverridden("TryGetIndex") ? base.BindGetIndex(binder, indexes) : this.CallMethodWithResult("TryGetIndex", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.GetArgArray(indexes), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackGetIndex((DynamicMetaObject) this, indexes, e)), (DynamicProxyMetaObject<T>.Fallback) null);
    }

    public virtual DynamicMetaObject BindSetIndex(
      SetIndexBinder binder,
      DynamicMetaObject[] indexes,
      DynamicMetaObject value)
    {
      return !this.IsOverridden("TrySetIndex") ? base.BindSetIndex(binder, indexes, value) : this.CallMethodReturnLast("TrySetIndex", (DynamicMetaObjectBinder) binder, (IEnumerable<Expression>) DynamicProxyMetaObject<T>.GetArgArray(indexes, value), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackSetIndex((DynamicMetaObject) this, indexes, value, e)));
    }

    public virtual DynamicMetaObject BindDeleteIndex(
      DeleteIndexBinder binder,
      DynamicMetaObject[] indexes)
    {
      return !this.IsOverridden("TryDeleteIndex") ? base.BindDeleteIndex(binder, indexes) : this.CallMethodNoResult("TryDeleteIndex", (DynamicMetaObjectBinder) binder, DynamicProxyMetaObject<T>.GetArgArray(indexes), (DynamicProxyMetaObject<T>.Fallback) (e => binder.FallbackDeleteIndex((DynamicMetaObject) this, indexes, e)));
    }

    private static Expression[] NoArgs
    {
      get
      {
        return CollectionUtils.ArrayEmpty<Expression>();
      }
    }

    private static IEnumerable<Expression> GetArgs(
      params DynamicMetaObject[] args)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      return (IEnumerable<Expression>) Enumerable.Select<DynamicMetaObject, Expression>((IEnumerable<M0>) args, (Func<M0, M1>) (DynamicProxyMetaObject<T>.\u003C\u003Ec.\u003C\u003E9__18_0 ?? (DynamicProxyMetaObject<T>.\u003C\u003Ec.\u003C\u003E9__18_0 = new Func<DynamicMetaObject, Expression>((object) DynamicProxyMetaObject<T>.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CGetArgs\u003Eb__18_0)))));
    }

    private static Expression[] GetArgArray(DynamicMetaObject[] args)
    {
      return (Expression[]) new NewArrayExpression[1]
      {
        Expression.NewArrayInit(typeof (object), DynamicProxyMetaObject<T>.GetArgs(args))
      };
    }

    private static Expression[] GetArgArray(
      DynamicMetaObject[] args,
      DynamicMetaObject value)
    {
      Expression expression = value.get_Expression();
      return new Expression[2]
      {
        (Expression) Expression.NewArrayInit(typeof (object), DynamicProxyMetaObject<T>.GetArgs(args)),
        expression.Type.IsValueType() ? (Expression) Expression.Convert(expression, typeof (object)) : expression
      };
    }

    private static ConstantExpression Constant(DynamicMetaObjectBinder binder)
    {
      Type type = ((object) binder).GetType();
      while (!type.IsVisible())
        type = type.BaseType();
      return Expression.Constant((object) binder, type);
    }

    private DynamicMetaObject CallMethodWithResult(
      string methodName,
      DynamicMetaObjectBinder binder,
      IEnumerable<Expression> args,
      DynamicProxyMetaObject<T>.Fallback fallback,
      DynamicProxyMetaObject<T>.Fallback fallbackInvoke = null)
    {
      DynamicMetaObject fallbackResult = fallback((DynamicMetaObject) null);
      return this.BuildCallMethodWithResult(methodName, binder, args, fallbackResult, fallbackInvoke);
    }

    private DynamicMetaObject BuildCallMethodWithResult(
      string methodName,
      DynamicMetaObjectBinder binder,
      IEnumerable<Expression> args,
      DynamicMetaObject fallbackResult,
      DynamicProxyMetaObject<T>.Fallback fallbackInvoke)
    {
      ParameterExpression parameterExpression = Expression.Parameter(typeof (object), (string) null);
      IList<Expression> initial = (IList<Expression>) new List<Expression>();
      initial.Add((Expression) Expression.Convert(this.get_Expression(), typeof (T)));
      initial.Add((Expression) DynamicProxyMetaObject<T>.Constant(binder));
      initial.AddRange<Expression>(args);
      initial.Add((Expression) parameterExpression);
      DynamicMetaObject errorSuggestion = new DynamicMetaObject((Expression) parameterExpression, (BindingRestrictions) BindingRestrictions.Empty);
      if (Type.op_Inequality(binder.get_ReturnType(), typeof (object)))
        errorSuggestion = new DynamicMetaObject((Expression) Expression.Convert(errorSuggestion.get_Expression(), binder.get_ReturnType()), errorSuggestion.get_Restrictions());
      if (fallbackInvoke != null)
        errorSuggestion = fallbackInvoke(errorSuggestion);
      return new DynamicMetaObject((Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[1]
      {
        parameterExpression
      }, new Expression[1]
      {
        (Expression) Expression.Condition((Expression) Expression.Call((Expression) Expression.Constant((object) this._proxy), typeof (DynamicProxy<T>).GetMethod(methodName), (IEnumerable<Expression>) initial), errorSuggestion.get_Expression(), fallbackResult.get_Expression(), binder.get_ReturnType())
      }), this.GetRestrictions().Merge(errorSuggestion.get_Restrictions()).Merge(fallbackResult.get_Restrictions()));
    }

    private DynamicMetaObject CallMethodReturnLast(
      string methodName,
      DynamicMetaObjectBinder binder,
      IEnumerable<Expression> args,
      DynamicProxyMetaObject<T>.Fallback fallback)
    {
      DynamicMetaObject dynamicMetaObject = fallback((DynamicMetaObject) null);
      ParameterExpression parameterExpression = Expression.Parameter(typeof (object), (string) null);
      IList<Expression> initial = (IList<Expression>) new List<Expression>();
      initial.Add((Expression) Expression.Convert(this.get_Expression(), typeof (T)));
      initial.Add((Expression) DynamicProxyMetaObject<T>.Constant(binder));
      initial.AddRange<Expression>(args);
      initial[initial.Count - 1] = (Expression) Expression.Assign((Expression) parameterExpression, initial[initial.Count - 1]);
      return new DynamicMetaObject((Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[1]
      {
        parameterExpression
      }, new Expression[1]
      {
        (Expression) Expression.Condition((Expression) Expression.Call((Expression) Expression.Constant((object) this._proxy), typeof (DynamicProxy<T>).GetMethod(methodName), (IEnumerable<Expression>) initial), (Expression) parameterExpression, dynamicMetaObject.get_Expression(), typeof (object))
      }), this.GetRestrictions().Merge(dynamicMetaObject.get_Restrictions()));
    }

    private DynamicMetaObject CallMethodNoResult(
      string methodName,
      DynamicMetaObjectBinder binder,
      Expression[] args,
      DynamicProxyMetaObject<T>.Fallback fallback)
    {
      DynamicMetaObject dynamicMetaObject = fallback((DynamicMetaObject) null);
      IList<Expression> initial = (IList<Expression>) new List<Expression>();
      initial.Add((Expression) Expression.Convert(this.get_Expression(), typeof (T)));
      initial.Add((Expression) DynamicProxyMetaObject<T>.Constant(binder));
      initial.AddRange<Expression>((IEnumerable<Expression>) args);
      return new DynamicMetaObject((Expression) Expression.Condition((Expression) Expression.Call((Expression) Expression.Constant((object) this._proxy), typeof (DynamicProxy<T>).GetMethod(methodName), (IEnumerable<Expression>) initial), (Expression) Expression.Empty(), dynamicMetaObject.get_Expression(), typeof (void)), this.GetRestrictions().Merge(dynamicMetaObject.get_Restrictions()));
    }

    private BindingRestrictions GetRestrictions()
    {
      return this.get_Value() != null || !this.get_HasValue() ? BindingRestrictions.GetTypeRestriction(this.get_Expression(), this.get_LimitType()) : BindingRestrictions.GetInstanceRestriction(this.get_Expression(), (object) null);
    }

    public virtual IEnumerable<string> GetDynamicMemberNames()
    {
      return this._proxy.GetDynamicMemberNames((T) this.get_Value());
    }

    private delegate DynamicMetaObject Fallback(DynamicMetaObject errorSuggestion);

    private sealed class GetBinderAdapter : GetMemberBinder
    {
      internal GetBinderAdapter(InvokeMemberBinder binder)
      {
        this.\u002Ector(binder.get_Name(), binder.get_IgnoreCase());
      }

      public virtual DynamicMetaObject FallbackGetMember(
        DynamicMetaObject target,
        DynamicMetaObject errorSuggestion)
      {
        throw new NotSupportedException();
      }
    }
  }
}
