﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Utilities.BufferUtils
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json.Utilities
{
  internal static class BufferUtils
  {
    public static char[] RentBuffer(IArrayPool<char> bufferPool, int minSize)
    {
      return bufferPool == null ? new char[minSize] : bufferPool.Rent(minSize);
    }

    public static void ReturnBuffer(IArrayPool<char> bufferPool, char[] buffer)
    {
      bufferPool?.Return(buffer);
    }

    public static char[] EnsureBufferSize(IArrayPool<char> bufferPool, int size, char[] buffer)
    {
      if (bufferPool == null)
        return new char[size];
      if (buffer != null)
        bufferPool.Return(buffer);
      return bufferPool.Rent(size);
    }
  }
}
