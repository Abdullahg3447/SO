﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Utilities.FSharpUtils
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace Newtonsoft.Json.Utilities
{
  internal static class FSharpUtils
  {
    private static readonly object Lock = new object();
    private static bool _initialized;
    private static MethodInfo _ofSeq;
    private static Type _mapType;
    public const string FSharpSetTypeName = "FSharpSet`1";
    public const string FSharpListTypeName = "FSharpList`1";
    public const string FSharpMapTypeName = "FSharpMap`2";

    public static Assembly FSharpCoreAssembly { get; private set; }

    public static MethodCall<object, object> IsUnion { get; private set; }

    public static MethodCall<object, object> GetUnionCases { get; private set; }

    public static MethodCall<object, object> PreComputeUnionTagReader { get; private set; }

    public static MethodCall<object, object> PreComputeUnionReader { get; private set; }

    public static MethodCall<object, object> PreComputeUnionConstructor { get; private set; }

    public static Func<object, object> GetUnionCaseInfoDeclaringType { get; private set; }

    public static Func<object, object> GetUnionCaseInfoName { get; private set; }

    public static Func<object, object> GetUnionCaseInfoTag { get; private set; }

    public static MethodCall<object, object> GetUnionCaseInfoFields { get; private set; }

    public static void EnsureInitialized(Assembly fsharpCoreAssembly)
    {
      if (FSharpUtils._initialized)
        return;
      object obj = FSharpUtils.Lock;
      bool flag = false;
      try
      {
        Monitor.Enter(obj, ref flag);
        if (FSharpUtils._initialized)
          return;
        FSharpUtils.FSharpCoreAssembly = fsharpCoreAssembly;
        Type type1 = fsharpCoreAssembly.GetType("Microsoft.FSharp.Reflection.FSharpType");
        FSharpUtils.IsUnion = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>((MethodBase) FSharpUtils.GetMethodWithNonPublicFallback(type1, "IsUnion", BindingFlags.Static | BindingFlags.Public));
        FSharpUtils.GetUnionCases = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>((MethodBase) FSharpUtils.GetMethodWithNonPublicFallback(type1, "GetUnionCases", BindingFlags.Static | BindingFlags.Public));
        Type type2 = fsharpCoreAssembly.GetType("Microsoft.FSharp.Reflection.FSharpValue");
        FSharpUtils.PreComputeUnionTagReader = FSharpUtils.CreateFSharpFuncCall(type2, "PreComputeUnionTagReader");
        FSharpUtils.PreComputeUnionReader = FSharpUtils.CreateFSharpFuncCall(type2, "PreComputeUnionReader");
        FSharpUtils.PreComputeUnionConstructor = FSharpUtils.CreateFSharpFuncCall(type2, "PreComputeUnionConstructor");
        Type type3 = fsharpCoreAssembly.GetType("Microsoft.FSharp.Reflection.UnionCaseInfo");
        FSharpUtils.GetUnionCaseInfoName = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(type3.GetProperty("Name"));
        FSharpUtils.GetUnionCaseInfoTag = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(type3.GetProperty("Tag"));
        FSharpUtils.GetUnionCaseInfoDeclaringType = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(type3.GetProperty("DeclaringType"));
        FSharpUtils.GetUnionCaseInfoFields = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>((MethodBase) type3.GetMethod("GetFields"));
        FSharpUtils._ofSeq = fsharpCoreAssembly.GetType("Microsoft.FSharp.Collections.ListModule").GetMethod("OfSeq");
        FSharpUtils._mapType = fsharpCoreAssembly.GetType("Microsoft.FSharp.Collections.FSharpMap`2");
        Thread.MemoryBarrier();
        FSharpUtils._initialized = true;
      }
      finally
      {
        if (flag)
          Monitor.Exit(obj);
      }
    }

    private static MethodInfo GetMethodWithNonPublicFallback(
      Type type,
      string methodName,
      BindingFlags bindingFlags)
    {
      MethodInfo method = type.GetMethod(methodName, bindingFlags);
      if (MethodInfo.op_Equality(method, (MethodInfo) null) && (bindingFlags & BindingFlags.NonPublic) != BindingFlags.NonPublic)
        method = type.GetMethod(methodName, bindingFlags | BindingFlags.NonPublic);
      return method;
    }

    private static MethodCall<object, object> CreateFSharpFuncCall(
      Type type,
      string methodName)
    {
      MethodInfo nonPublicFallback = FSharpUtils.GetMethodWithNonPublicFallback(type, methodName, BindingFlags.Static | BindingFlags.Public);
      MethodInfo method = nonPublicFallback.ReturnType.GetMethod("Invoke", BindingFlags.Instance | BindingFlags.Public);
      MethodCall<object, object> call = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>((MethodBase) nonPublicFallback);
      MethodCall<object, object> invoke = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>((MethodBase) method);
      return (MethodCall<object, object>) ((target, args) => (object) new FSharpFunction(call(target, args), invoke));
    }

    public static ObjectConstructor<object> CreateSeq(Type t)
    {
      return JsonTypeReflector.ReflectionDelegateFactory.CreateParameterizedConstructor((MethodBase) FSharpUtils._ofSeq.MakeGenericMethod(t));
    }

    public static ObjectConstructor<object> CreateMap(Type keyType, Type valueType)
    {
      return (ObjectConstructor<object>) typeof (FSharpUtils).GetMethod("BuildMapCreator").MakeGenericMethod(keyType, valueType).Invoke((object) null, (object[]) null);
    }

    public static ObjectConstructor<object> BuildMapCreator<TKey, TValue>()
    {
      ObjectConstructor<object> ctorDelegate = JsonTypeReflector.ReflectionDelegateFactory.CreateParameterizedConstructor((MethodBase) FSharpUtils._mapType.MakeGenericType(typeof (TKey), typeof (TValue)).GetConstructor(new Type[1]
      {
        typeof (IEnumerable<Tuple<TKey, TValue>>)
      }));
      return (ObjectConstructor<object>) (args =>
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        IEnumerable<Tuple<TKey, TValue>> tuples = (IEnumerable<Tuple<TKey, TValue>>) Enumerable.Select<KeyValuePair<TKey, TValue>, Tuple<TKey, TValue>>((IEnumerable<M0>) args[0], (Func<M0, M1>) (FSharpUtils.\u003C\u003Ec__52<TKey, TValue>.\u003C\u003E9__52_1 ?? (FSharpUtils.\u003C\u003Ec__52<TKey, TValue>.\u003C\u003E9__52_1 = new Func<KeyValuePair<TKey, TValue>, Tuple<TKey, TValue>>((object) FSharpUtils.\u003C\u003Ec__52<TKey, TValue>.\u003C\u003E9, __methodptr(\u003CBuildMapCreator\u003Eb__52_1)))));
        return ctorDelegate(new object[1]{ (object) tuples });
      });
    }
  }
}
