﻿// Decompiled with JetBrains decompiler
// Type: Newtonsoft.Json.Utilities.FSharpFunction
// Assembly: SonOyuncuMinecraftLauncher, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 6DBFCC83-ADAE-4F76-9F31-C5932EDD8FCE
// Assembly location: C:\Users\Abdullah\Desktop\SonOyuncuMinecraftLauncher.exe

namespace Newtonsoft.Json.Utilities
{
  internal class FSharpFunction
  {
    private readonly object _instance;
    private readonly MethodCall<object, object> _invoker;

    public FSharpFunction(object instance, MethodCall<object, object> invoker)
    {
      this._instance = instance;
      this._invoker = invoker;
    }

    public object Invoke(params object[] args)
    {
      return this._invoker(this._instance, args);
    }
  }
}
